-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2023 at 05:47 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--
-- Error reading structure for table ecom.admin_users: #1932 - Table &#039;ecom.admin_users&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.admin_users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`admin_users`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--
-- Error reading structure for table ecom.categories: #1932 - Table &#039;ecom.categories&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.categories: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`categories`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--
-- Error reading structure for table ecom.contact_us: #1932 - Table &#039;ecom.contact_us&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.contact_us: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`contact_us`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `order`
--
-- Error reading structure for table ecom.order: #1932 - Table &#039;ecom.order&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.order: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`order`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--
-- Error reading structure for table ecom.order_detail: #1932 - Table &#039;ecom.order_detail&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.order_detail: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`order_detail`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--
-- Error reading structure for table ecom.order_status: #1932 - Table &#039;ecom.order_status&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.order_status: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`order_status`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `product`
--
-- Error reading structure for table ecom.product: #1932 - Table &#039;ecom.product&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.product: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`product`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--
-- Error reading structure for table ecom.sub_categories: #1932 - Table &#039;ecom.sub_categories&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.sub_categories: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`sub_categories`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table ecom.users: #1932 - Table &#039;ecom.users&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`users`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--
-- Error reading structure for table ecom.wishlist: #1932 - Table &#039;ecom.wishlist&#039; doesn&#039;t exist in engine
-- Error reading data for table ecom.wishlist: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `ecom`.`wishlist`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
