<?php
require('top.inc.php');

$categories_id = '';
$name = '';
$mrp = '';
$price = '';
$qty = '';
$image = '';
$short_desc = '';
$description = '';
$meta_title = '';
$meta_desc = '';
$meta_keyword = '';
$best_seller = '';
$sub_categories_id = '';


$msg = '';
$image_required = 'required';
if (isset($_GET['id']) && $_GET['id'] != '') {
  $image_required = '';
  $id = get_safe_value($con, $_GET['id']);
  $res = mysqli_query($con, "select * from product where id='$id'");
  $check = mysqli_num_rows($res);
  if ($check > 0) {

    $row = mysqli_fetch_assoc($res);
    $categories_id = $row['categories_id'];
    $sub_categories_id = $row['sub_categories_id'];
    $name = $row['name'];
    $mrp = $row['mrp'];
    $price = $row['price'];
    $qty = $row['qty'];
    $short_desc = $row['short_desc'];
    $description = $row['description'];
    $meta_title = $row['meta_title'];
    $meta_desc = $row['meta_desc'];
    $meta_keyword = $row['meta_keyword'];
    $best_seller = $row['best_seller'];


  } else {

    header('location:product.php');
    die();
  }
}

if (isset($_POST['submit'])) {
  $categories_id = get_safe_value($con, $_POST['categories_id']);
  $sub_categories_id = get_safe_value($con, $_POST['sub_categories_id']);
  $name = get_safe_value($con, $_POST['name']);
  $mrp = get_safe_value($con, $_POST['mrp']);
  $price = get_safe_value($con, $_POST['price']);
  $qty = get_safe_value($con, $_POST['qty']);
  $short_desc = get_safe_value($con, $_POST['short_desc']);
  $description = get_safe_value($con, $_POST['description']);
  $meta_title = get_safe_value($con, $_POST['meta_title']);
  $meta_desc = get_safe_value($con, $_POST['meta_desc']);
  $meta_keyword = get_safe_value($con, $_POST['meta_keyword']);
  $best_seller = get_safe_value($con, $_POST['best_seller']);

  $res = mysqli_query($con, "select * from product where name='$name'");
  $check = mysqli_num_rows($res);
  if ($check > 0) {
    if (isset($_GET['id']) && $_GET['id'] != '') {
      $getData = mysqli_fetch_assoc($res);
      if ($id == $getData['id']) {

      } else {
        $msg = " product already exists";
      }
    } else {
      $msg = " product already exists";
    }
  }
  if ($_FILES['image']['type'] != '' && ($_FILES['image']['type'] != 'image/png' && $_FILES['image']['type'] != 'image/jpg' && $_FILES['image']['type'] != 'image/jpeg')) {
    $msg = "Only png/jpg/jpeg image format";

  }
  if ($msg == '') {
    if (isset($_GET['id']) && $_GET['id'] != '') {
      if ($_FILES['image']['name'] != '') {
        $image = rand(111111111, 99999999) . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], PRODUCT_IMAGE_SERVER_PATH . $image);
        $update_sql = "update product set categories_id='$categories_id',name='$name',mrp='$mrp',price='$price',qty='$qty',short_desc='$short_desc',description='$description',meta_title='$meta_title',meta_desc='$meta_desc',meta_keyword='$meta_keyword',image='$image',sub_categories_id='$sub_categories_id',best_seller='$best_seller' where id='$id'";
      } else {
        $update_sql = "update product set categories_id='$categories_id',name='$name',mrp='$mrp',price='$price',qty='$qty',short_desc='$short_desc',description='$description',meta_title='$meta_title',meta_desc='$meta_desc',meta_keyword='$meta_keyword',sub_categories_id='$sub_categories_id',best_seller='$best_seller' where id='$id'";



      }
      mysqli_query($con, $update_sql);
    } else {
      $image = rand(111111111, 99999999) . '_' . $_FILES['image']['name'];
      move_uploaded_file($_FILES['image']['tmp_name'], PRODUCT_IMAGE_SERVER_PATH . $image);
      mysqli_query($con, "insert into product(categories_id,name,mrp,price,qty,short_desc,description,meta_title,meta_desc,meta_keyword,status,image,best_seller,sub_categories_id) values('$categories_id','$name','$mrp','$price','$qty','$short_desc','$description','$meta_title','$meta_desc','$meta_keyword',1,'$image','$best_seller','$sub_categories_id')");
    }
    header('location:product.php');
    die();

  }
}
?>
<!DOCTYPE html>
<html>

<head>
  <title>Form Example</title>
  <link rel="stylesheet" type="text/css" href="manage_product.css">
</head>

<body>
  <h1>Update or Add New Product Here</h1>
  <form method="post" enctype="multipart/form-data">


    <label for="categories">Select Categories</label>
    <select name="categories_id" class="select" id="categories_id" onchange="get_sub_cat()">
      <option>Select Category</option>
      <?php
      $res = mysqli_query($con, "select id,categories from categories order by categories asc");
      while ($row = mysqli_fetch_assoc($res)) {
        if ($row['id'] == $categories_id) {
          echo "<option selected value=" . $row['id'] . ">" . $row['categories'] . "</option>";
        } else {
          echo "<option value=" . $row['id'] . ">" . $row['categories'] . "</option>";
        }
      }
      ?>
    </select><br>
    <label for="categories">Select Sub-Categories</label>
    <select name="sub_categories_id" id="sub_categories_id" class="select">
      <option>Select Category</option>
      <?php
      $res = mysqli_query($con, "select id,sub_categories from sub_categories order by sub_categories asc");
      while ($row = mysqli_fetch_assoc($res)) {
        if ($row['id'] == $sub_categories_id) {
          echo "<option selected value=" . $row['id'] . ">" . $row['sub_categories'] . "</option>";
        } else {
          echo "<option value=" . $row['id'] . ">" . $row['sub_categories'] . "</option>";
        }
      }
      ?>
    </select><br>



    <!-- best seller part -->



    <label for="categories">Best Seller</label>
    <select name="best_seller" id="sub_categories_id" class="select" required>
      <option value="">Select</option>
      <?php
      if ($best_seller == 1) {
        echo '<option value="1" selected>Yes</option>
												<option value="0">No</option>';
      } elseif ($best_seller == 0) {
        echo '<option value="1">Yes</option>
												<option value="0" selected>No</option>';
      } else {
        echo '<option value="1">Yes</option>
												<option value="0">No</option>';
      }
      ?>

    </select><br>







    <div class="pname">
      <label for="categories">Product Name</label><br>
      <input type="text" name="name" placeholder="enter product name" required value="<?php echo $name ?>">
    </div>

    <div class="pmrp">
      <label for="categories">MRP</label><br>
      <input type="text" name="mrp" placeholder="enter product mrp" required value="<?php echo $mrp ?>">
    </div>

    <div class="pprice">
      <label for="categories">Product PRICE</label><br>
      <input type="text" name="price" placeholder="enter product price" required value="<?php echo $price ?>">
    </div>

    <div class="pqty">
      <label for="categories">Product Qty</label><br>
      <input type="text" name="qty" placeholder="enter product qty" required value="<?php echo $qty ?>">
    </div>

    <div class="pimage">
      <label for="categories">Product Image</label><br>
      <input type="file" name="image" <?php echo $image_required ?>>
    </div>

    <div class="psd">
      <label for="categories">Short Description</label><br>
      <textarea name="short_desc" placeholder="Please enter product short description"
        required> <?php echo $short_desc ?></textarea>
    </div>

    <div class="pdesc">
      <label for="categories"> Description</label><br>
      <textarea name="description" placeholder="Please enter product  description"
        required> <?php echo $description ?></textarea>
    </div>

    <div class="pmt">
      <label for="categories"> Meta Title</label><br>
      <textarea name="meta_title" placeholder="Please enter product  meta title"> <?php echo $meta_title ?></textarea>
    </div>


    <div>
      <label for="pmd"> Meta Description</label><br>
      <textarea name="meta_desc"
        placeholder="Please enter product meta description"> <?php echo $meta_desc ?></textarea>
    </div>


    <div>
      <label for="pmk"> meta keyword</label><br>
      <textarea name="meta_keyword"
        placeholder="Please enter product meta  keyword"> <?php echo $meta_keyword ?></textarea>
    </div>





    <input type="submit" name="submit" value="Submit" class="submit-btn">
    <div class="field_error">
      <?php echo $msg ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
      function get_sub_cat(sub_cat_id) {
        var categories_id = jQuery('#categories_id').val();
        jQuery.ajax({
          url: 'get_sub_cat.php',
          type: 'post',
          data: 'categories_id=' + categories_id + '&sub_cat_id=' + sub_cat_id,
          success: function (result) {
            jQuery('#sub_categories_id').html(result);
          }
        });
      }
    </script>
  </form>

  <?php
  require('footer.inc.php'); ?>
  <script>
    <?php
    if (isset($_GET['id'])) {
      ?>
      get_sub_cat('<?php echo $sub_categories_id ?>');
    <?php } ?>
  </script>
</body>

</html>