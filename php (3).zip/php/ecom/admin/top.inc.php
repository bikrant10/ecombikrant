<?php
require('connection.inc.php');
require('function.inc.php');

if(isset($_SESSION['ADMIN_LOGIN']) && $_SESSION['ADMIN_USERNAME'] != ''){

}else{
    header('location:login.php');
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="top.inc.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        /* Navbar styles */
        .navbar {
            background-color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            margin-top: -10px;
            margin-right: -10px;
            margin-left: -10px;
        }
        
        .navbar a {
            color: #fff;
            text-decoration: none;
            margin-right: 10px;
        }
        
        .navbar a:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .navbar {
                flex-wrap: wrap;
                justify-content: center;
                padding: 10px;
            }
        
            .navbar a {
                margin: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="change_password.php" class="active">Change password</a>
        <a href="categories.php">Categories</a>
        <a href="sub_categories.php">Sub-Categories</a>
        <a href="product.php">Product</a>
        <a href="aorder.php">Order</a>
        <a href="users.php">Userr</a>
        <a href="contact_us.php">Message</a>
        <a href="logout.php" class="logout-btn"><i class="fa fa-sign-out"></i></a>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.querySelector('.logout-btn');
            logoutBtn.addEventListener('click', function(event) {
                event.preventDefault(); // Prevent the default link behavior
                // dialog box will appear
                if (confirm("Are you sure you want to log out?")) {
                    window.location.href = 'logout.php'; // Redirect to logout page
                }
            });
        });
    </script>
</body>
</html>
