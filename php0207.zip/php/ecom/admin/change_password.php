<!-- <?php
require('connection.inc.php');
require('function.inc.php');

// Check if the admin is logged in
if (!isset($_SESSION['ADMIN_LOGIN']) || $_SESSION['ADMIN_LOGIN'] != 'yes') {
    header('location: login.php');
    exit();
}

$msg = '';

// Process the form submission
if (isset($_POST['submit'])) {
    $currentPassword = get_safe_value($con, $_POST['current_password']);
    $newPassword = get_safe_value($con, $_POST['new_password']);
    $confirmPassword = get_safe_value($con, $_POST['confirm_password']);

    // Retrieve the admin's username from the session
    $username = $_SESSION['ADMIN_USERNAME'];

    // Verify the current password
    $sql = "SELECT password FROM admin_users WHERE username = '$username'";
    $res = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($res);
    $hashedPassword = $row['password'];
    if (password_verify($currentPassword, $hashedPassword)) {
        // Check if the new password and confirm password match
        if ($newPassword !== $confirmPassword) {
            $msg = "New password and confirm password do not match.";
        } else {
            // Update the password in the database
            $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $sql = "UPDATE admin_users SET password = '$hashedNewPassword' WHERE username = '$username'";
            mysqli_query($con, $sql);
            $msg = "Password changed successfully.";
        }
    } else {
        $msg = "Invalid current password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" type="text/css" href="admin_log.css">
</head>
<body>
    <h2>Change Password</h2>
    <div class="change-password">
        <form method="post">
            <label for="current_password">Current Password:</label>
            <input type="password" id="current_password" name="current_password" required>
            <br><br>
            <label for="new_password">New Password:</label>
            <input type="password" id="new_password" name="new_password" required>
            <br><br>
            <label for="confirm_password">Confirm New Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            <br><br>
            <button type="submit" name="submit">Change Password</button>
            <br><br>
            <div class="field_error"><?php echo $msg; ?></div>
        </form>
    </div>
</body>
</html> -->
