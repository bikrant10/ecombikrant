<?php
require('top.inc.php');
$order_id = get_safe_value($con, $_GET['id']);
if (isset($_POST['update_order_status'])) {
    $update_order_status = $_POST['update_order_status'];
    if ($update_order_status == '5') {
        mysqli_query($con, "update `order` set order_status='$update_order_status' where id='$order_id'");
    } else {
        mysqli_query($con, "update `order` set order_status='$update_order_status' where id='$order_id'");
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Design || Future Web</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        * {
            padding: 5px;
        }

        .field_error {
            color: red;
        }

        body {
            background-color: rgb(225, 236, 172);
        }

        h1 {
            padding-bottom: 0px;
            margin-top: -20px;
            margin-bottom: 0px;
            text-align: center;
        }

        /* TABEL KO PART HO HAI */
        .header_fixed {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            overflow-x: auto;
        }

        .table {
            width: 75%;
            border-collapse: collapse;
            border: 1px solid #ccc;
            font-size: 15px;
            margin-left: 110px;

        }

        .table thead th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        .table tbody td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            border-right: 1px solid #ccc;
        }

        .table tbody td:last-child {
            border-right: none;
        }

        .table tbody td:first-child {
            font-weight: bold;
        }

        .table tfoot td {
            padding: 10px;
            font-weight: bold;
            border-top: 1px solid #ccc;
            border-right: 1px solid #ccc;
        }

        .table tfoot td:last-child {
            border-right: none;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            color: #ffffff;
            transition: background-color 0.3s ease;
        }

        .button3 {
            background-color: #1abc9c;
        }

        .button:hover {
            background-color: #f10707;
        }

        @media only screen and (max-width: 768px) {
            h1 {
                font-size: 24px;
            }

            .header_fixed {
                padding: 10px 0px 10px 0px;
            }

            .table {
                font-size: 7px;
            }

            .table thead th,
            .table tbody td {
                padding: 5px;
            }

            .button {
                padding: 5px 0px 5px 0px;
            }
        }

        img {
            height: 80px;
            width: 100px;
        }

        .subtotal-box {
            text-align: right;
            display: block;
        }

        .subtotal-box h4 {
            text-align: right;
            margin: 0;
        }
    </style>
</head>

<body>
    <br>
    <h1>ORDER DETAILS</h1>

    <div class="header_fixed">
        <table class="table">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Product Image</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total Price</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $res = mysqli_query($con, "select distinct(order_detail.id), order_detail.*, product.name, product.image, `order`.address, `order`.city, `order`.pincode from order_detail, product, `order` where order_detail.order_id='$order_id' and order_detail.product_id=product.id GROUP by order_detail.id");
                $total_price = 0;

                $userInfo = mysqli_fetch_assoc(mysqli_query($con, "select * from `order` where id='$order_id'"));

                $address = $userInfo['address'];
                $city = $userInfo['city'];
                $pincode = $userInfo['pincode'];

                while ($row = mysqli_fetch_assoc($res)) {
                    $total_price = $total_price + ($row['qty'] * $row['price']);
                    ?>
                    <tr>
                        <td>
                            <?php echo $row['name'] ?>
                        </td>
                        <td><img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $row['image'] ?>"></td>
                        <td>
                            <?php echo $row['qty'] ?>
                        </td>
                        <td>
                            <?php echo $row['price'] ?>
                        </td>
                        <td>
                            <?php echo $row['qty'] * $row['price'] ?>
                        </td>
                    </tr>
                <?php } ?>
                <tr>
                    <td colspan="4" style="text-align: right; font-weight: bold;">Subtotal:</td>
                    <td>
                        <?php echo $total_price; ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="5">
                        <strong>Address:</strong>
                        <?php echo $address ?>,
                        <?php echo $city ?>,
                        <?php echo $pincode ?>
                        <br /><br />
                        <strong>Order Status: </strong>
                        <?php
                        $order_status_arr = mysqli_fetch_assoc(mysqli_query($con, "select order_status.name from order_status, `order` where `order`.id='$order_id' and `order`.order_status=order_status.id"));
                        echo $order_status_arr['name'];
                        ?>
                        <div>
                            <form method="post">
                                <select class="form-control" name="update_order_status" required>
                                    <option value="">Select Status</option>
                                    <?php
                                    $res = mysqli_query($con, "select * from order_status");
                                    while ($row = mysqli_fetch_assoc($res)) {
                                        if ($row['id'] == $categories_id) {
                                            echo "<option selected value=" . $row['id'] . ">" . $row['name'] . "</option>";
                                        } else {
                                            echo "<option value=" . $row['id'] . ">" . $row['name'] . "</option>";
                                        }
                                    }
                                    ?>
                                </select>
                                <input type="submit" class="form-control" />
                            </form>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <?php
    require('footer.inc.php');
    ?>

</html>