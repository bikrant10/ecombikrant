<?php
require('top.inc.php');

$sql = "SELECT `order`.id, users.name, `order`.added_on, `order`.address, `order`.city, `order`.pincode, `order`.payment_type, order_status.name AS order_status_str
        FROM `order`
        JOIN users ON users.id = `order`.user_id
        JOIN order_status ON order_status.id = `order`.order_status
        ORDER BY `order`.id DESC";
$res = mysqli_query($con, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Design || Future Web</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        * {
            padding: 5px;
        }

        .field_error {
            color: red;
        }

        body {
            background-color: rgb(225, 236, 172);
        }

        h1 {
            padding-bottom: 0px;
            margin-top: -20px;
            margin-bottom: 0px;
            text-align: center;
        }

        /* TABEL KO PART HO HAI */
        .header_fixed {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ccc;
        }

        .table thead th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        .table tbody td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            border-right: 1px solid #ccc;
        }

        .table tbody td:last-child {
            border-right: none;
        }

        .table tbody td:first-child {
            font-weight: bold;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            color: #ffffff;
            transition: background-color 0.3s ease;
        }

        .button3 {
            background-color: #1abc9c;
        }

        .button:hover {
            background-color: #f10707;
        }

        @media only screen and (max-width: 768px) {
            h1 {
                font-size: 24px;
            }

            .header_fixed {
                padding: 10px 0px 10px 0px;
            }

            .table {
                font-size: 7px;

            }

            .table thead th,
            .table tbody td {
                padding: 5px;
            }

            .button {
                padding: 5px 0px 5px 0px;
            }

        }
    </style>

</head>

<body>
    <br>
    <h1>ORDER</h1>

    <div class="header_fixed">
        <table class="table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Name</th>
                    <th>Order Date</th>
                    <th> Address</th>
                    <th> Payment Type</th>
                    <th> Order Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
    while ($row = mysqli_fetch_assoc($res)) {
        ?>
                    <tr>
                        <td class="product-add-to-cart"><a href="aorder_detail.php?id=<?php echo $row['id'] ?>"> <?php echo $row['id'] ?></a></td>
                        <td class="product-name">
                        <?php echo $row['name'] ?>
                        </td>
                        <td class="product-name">
                            <?php echo $row['added_on'] ?>
                        </td>
                        <td class="product-name">
                            <?php echo $row['address'] ?><br />
                            <?php echo $row['city'] ?><br />
                            <?php echo $row['pincode'] ?>
                        </td>
                        <td class="product-name">
                            <?php echo $row['payment_type'] ?>
                        </td>
                        <td class="product-name">
                            <?php echo $row['order_status_str'] ?>
                        </td>

                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>

<?php
require('footer.inc.php');
?>

</html>