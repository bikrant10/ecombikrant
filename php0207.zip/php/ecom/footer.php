
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <link rel="stylesheet" href="footer.css">
 
</head>
<body>
  <footer>
    <div class="footer-section">
      <div class="about-us">
        <h3 class="A1">About Us</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem magnam ratione suscipit ea ut, voluptate vero quis incidunt sequi debitis.

        </p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-linkedin-in"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
      </div>

      <div class="information">
        <h3  class="A2">MY ACCOUNT</h3>
        <div class="subcategories">
          <a href="link1.html">My Account</a><br>
          <a href="cart.php">My Cart</a><br>
          <a href="link3.html">Login</a><br>
          <a href="wishlist.php">Wishlist</a><br>
          <a href="checkout.php">Checkout</a><br>
        </div>
      </div>

      <div class="newsletter">
    <h3  class="A3">newsletter</h3>
        <input type="email" placeholder="Enter your email address">
        <button type="submit">Subscribe</button>
      </div>
    </div>

    <div class="copyright">
      <p>&copy; Bikrant 2023. All Rights Reserved.</p>
    </div>
  </footer>
</body>
</html>
