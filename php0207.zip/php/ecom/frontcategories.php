<?php
require('top.php');
$cat_id=mysqli_real_escape_string($con,$_GET['id']);
$sub_categories='';
if(isset($_GET['sub_categories'])){
	$sub_categories=mysqli_real_escape_string($con,$_GET['sub_categories']);
}



if($cat_id>0){
  $get_product = get_product($con,'',$cat_id,'','',$sub_categories);
}else{
	?>
	<script>
	window.location.href='index.php';
	</script>
	<?php
}		
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="body.css">
  <style>
    
.image-container {
  position: relative;
  display: inline-block;
}

.wishlist-icon {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 24px;
  color: #ccc;
  opacity: 0;
  transition: opacity 0.3s ease;
  cursor: pointer;
}

.wishlist-icon.selected {
  color: red;
  opacity: 1;
}

.image-container:hover .wishlist-icon:not(.selected) {
  opacity: 1;
}

.disable-hover .wishlist-icon {
  opacity: 1;
}
  </style>
  <title>Document</title>
</head>
<body>
<section class="new-arrivals">
  
<?php if(count($get_product)>0) { ?>
  <div class="product-grid">
    <?php
    
    foreach ($get_product as $list) {
    ?>
      <div class="product">
        <div class="product-image">
        <div class="image-container">
  <img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$list['image'] ?>" alt="Product 1" class="a1">
  <a href="#"><i class="wishlist-icon far fa-heart"></i></a>
  
</div>
          <div class="product-info">
            <h5><a href="product_details.php?id=<?php echo $list['id'] ?>"><?php echo $list['name'] ?></a></h5>
            <ul class="info">
              <li class="oldprice"><?php echo $list['mrp'] ?></li>
              <li><?php echo $list['price'] ?></li>
            </ul>
          </div>
        </div>
      </div>
    <?php } ?>
  </div>

  <?php } else{
    echo "data not found";
  } ?>
</section>
<script>
// document.addEventListener("DOMContentLoaded", function() {
//   const imageContainers = document.querySelectorAll(".image-container");

//   imageContainers.forEach(function(container) {
//     const wishlistIcon = container.querySelector(".wishlist-icon");

//     container.addEventListener("mouseenter", function() {
//       wishlistIcon.style.opacity = 1;
//     });

//     container.addEventListener("mouseleave", function() {
//       if (!wishlistIcon.classList.contains("selected")) {
//         wishlistIcon.style.opacity = 0;
//       }
//     });

//     wishlistIcon.addEventListener("click", function() {
//       wishlistIcon.classList.toggle("selected");
//       container.classList.toggle("disable-hover");
//     });
//   });
// });

  </script>
</body>
</html>
 
<?php
require('footer.php');?>
</html>
