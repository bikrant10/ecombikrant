<?php
require('top.php');
if (!isset($_SESSION['USER_LOGIN'])) {
    ?>
    <script>
        window.location.href = 'index.php';
    </script>
    <?php
}
$order_id = get_safe_value($con, $_GET['id']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            box-sizing: border-box;
        }

        .wishlist-table {
            width: 100%;
            border-collapse: collapse;
            text-align: center;
            /* Add this line */
        }

        .wishlist-table th,
        .wishlist-table td {
            padding: 5px;
            border: 1px solid rgb(148, 136, 136);
            text-align: center;
            /* Add this line */
        }

        .wishlist-table th {
            background-color: #f2f2f2;
        }

        .remove-button,
        .add-to-cart-button {
            background-color: #ff0000;
            color: #fff;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        .add-to-cart-button {
            background-color: #008000;
        }

        .a12 {

            width: 92px;
            height: 122px;

        }

        .table-container {
            padding: 100px 50px 150px 50px;


        }
        .subtotal-box {
      text-align: right;
    
      display: block;
    }

    .subtotal-box h4 {
      text-align: right;
      margin: 0;
    }

    </style>
</head>

<body>
    <div class="table-container">
        <table class="wishlist-table">
            <thead>
                <tr>
                    <th>PRODUCT NAME</th>
                    <th>PRODUCT IMAGE</th>
                    <th>QTY</th>
                    <th>PRICE</th>
                    <th>TOTAL PRICE</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $uid = $_SESSION['USER_ID'];
                $res = mysqli_query($con, "select distinct(order_detail.id) ,order_detail.*,product.name,product.image from order_detail,product ,`order` where order_detail.order_id='$order_id' and `order`.user_id='$uid' and order_detail.product_id=product.id");
                $total_price = 0;

                while ($row = mysqli_fetch_assoc($res)) {
                    $total_price = $total_price + ($row['qty'] * $row['price']);


                    ?>
                    <tr>
                        <td>
                            <?php echo $row['name'] ?>
                        </td>
                        <td> <img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $row['image'] ?>"></td>
                        <td>
                            <?php echo $row['qty'] ?>
                        </td>
                        <td>
                            <?php echo $row['price'] ?>
                        </td>
                        <td>
                            <?php echo $row['qty'] * $row['price'] ?>
                        </td>

                    </tr>

                <?php } ?>
            </tbody>
        </table>
        <div class="subtotal-box">
            <h4>Subtotal:
                <?php echo $total_price; ?>
            </h4>
        </div>
    </div>
</body>
<?php
require('footer.php'); ?>

</html>