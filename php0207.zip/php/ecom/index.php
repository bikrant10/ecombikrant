<?php
header("Location: body.php");
exit();
?>