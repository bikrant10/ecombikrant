<?php
require('top.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Contact Form</title>
  <link rel="stylesheet" href="contactfrontend.css">
</head>
<body>
  <div class="container">
    <h2>Contact Us</h2>
    
    <div class="contact-info">
      <h3>Contact Information</h3>
      <p><span>Address:</span> 123 Main St, City, Country</p>
      <p><span>Phone:</span> <a href="tel:+1234567890">+1 234 567 890</a></p>
      <p><span>Email:</span> <a href="mailto:info@example.com">info@example.com</a></p>
    </div>
    <h2>Send Mail</h2>
    <form  method="POST" class="opop">
      <label for="name">Your Name</label>
      <input type="text" id="name" name="name" placeholder="Enter your name" required>
      
      <label for="email">Your Email</label>
      <input type="email" id="email" name="email" placeholder="Enter your email" required>
      
      <label for="phone">Your Phone Number</label>
      <input type="tel" id="mobile" name="mobile" pattern="[1-9]{1}[0-9]{9}" required>
      
      <label for="comment">Your Message</label>
      <textarea id="comment" name="comment" placeholder="Enter your message" required></textarea>
      
      <button type="button" onclick="send_message()">Send Message</button>
    </form>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <script>
    function send_message(){
	var name=jQuery("#name").val();
	var email=jQuery("#email").val();
	var mobile=jQuery("#mobile").val();
	var comment=jQuery("#comment").val();
	
	if(name==""){
		alert('Please enter name');
	}else if(email==""){
		alert('Please enter email');
	}else if(mobile==""){
		alert('Please enter mobile');
	}else if(comment==""){
		alert('Please enter message');
	}else{
		jQuery.ajax({
			url:'send_message.php',
			type:'post',
			data:'name='+name+'&email='+email+'&mobile='+mobile+'&comment='+comment,
			success:function(result){
				alert(result);
                
			}	
		});
	}
}

  </script>
</body>
<?php
require('footer.php');?>
</html>
