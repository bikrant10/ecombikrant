-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2023 at 08:19 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'bikrant', 'bikrant123');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categories`, `status`) VALUES
(56, 'TV', 1),
(57, 'LAPTOP', 1),
(58, 'MOBILE', 1),
(59, 'FRIDGE', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(75) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `comment` text NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `mobile`, `comment`, `added_on`) VALUES
(13, 'a', 'bik@gmail.com', '9874563210', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus elementum enim massa, ac suscipit lorem vehicula vitae. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse in ligula ultricies, facilisis justo sed, feugiat mi. Suspendisse vitae augue dui. Sed neque elit, fermentum non tortor ac, dapibus vehicula diam. Praesent nec aliquam nisi.\n\nMorbi eget sem pretium lectus ultricies malesuada. In hac habitasse platea dictumst. Donec nec consequat sem. Suspendisse dignissim purus sit amet viverra vestibulum. Ut quis mauris volutpat, tempus enim in, sagittis arcu. Quisque at facilisis est, vel fermentum elit. Maecenas id urna ac orci scelerisque pretium vitae at mi. Donec cursus blandit felis, id sollicitudin ante sodales vel. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Proin feugiat ornare tortor.\n\nProin nec porttitor nibh. Duis ac magna nunc. Mauris feugiat, leo eget fringilla convallis, massa mi volutpat dui, at tincidunt nulla ipsum a lorem. Nullam magna mi, imperdiet tristique consequat a, viverra sed enim. Curabitur feugiat orci at finibus lacinia. Maecenas et ipsum ligula. Vestibulum scelerisque, ex vulputate ultricies vehicula, massa metus mattis lacus, in vestibulum metus sapien ullamcorper nibh.\n\nDuis venenatis erat enim, vel imperdiet magna ullamcorper quis. In ante nibh, viverra non rhoncus vitae, elementum eu nibh. Phasellus quis ultricies magna. Aliquam eget massa pretium, lobortis dolor nec, posuere felis. Nunc condimentum viverra dui sit amet laoreet. Praesent maximus auctor erat. Proin finibus purus at vestibulum lobortis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean cursus mi urna, a volutpat dui porttitor non. Nulla tristique velit id mattis bibendum. Sed tristique fringilla nisi et rhoncus. Fusce accumsan ex vitae lorem ornare tempus id nec orci. Sed eu egestas risus, at congue metus. Nullam et massa dolor. Nam vel tincidunt diam, quis mollis nisl.', '2023-06-24 10:23:37');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `sub_categories_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mrp` float NOT NULL,
  `price` float NOT NULL,
  `qty` int(11) NOT NULL,
  `image` text NOT NULL,
  `short_desc` text NOT NULL,
  `description` text NOT NULL,
  `meta_title` varchar(2000) NOT NULL,
  `meta_desc` varchar(2000) NOT NULL,
  `meta_keyword` varchar(2000) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `categories_id`, `sub_categories_id`, `name`, `mrp`, `price`, `qty`, `image`, `short_desc`, `description`, `meta_title`, `meta_desc`, `meta_keyword`, `status`) VALUES
(27, 59, 26, 'Samsung Fridge', 55000, 51000, 4, '109830000_sfridge.jpg', 'heolo', 'wewewe', '', '', '', 1),
(34, 56, 20, 'Samsung TV', 55000, 51000, 5, '109274518_lcdtv.jpg', 'asdas', 'adsasas', '', '', '', 1),
(35, 59, 27, 'Samsung Fridgee', 121212, 99999, 4, '109665449_dfridge.jpg', 'gfgf', 'gfgfgrf', '', '', '', 1),
(36, 57, 22, 'ACER NITRO 5', 125000, 122000, 5, '103967320_acernitro5laptop.jpg', 'DGDG', 'DGDG', '', '', '', 1),
(37, 57, 23, 'Acer Aspire', 90000, 85000, 80, '110355278_aceraspirelaptop.jpg', 'hfhf', 'fhfhfh', '', '', '', 1),
(38, 58, 24, 'ONE PLUS NORD', 55000, 51000, 4, '110076858_oneplusnord.png', 'fdfdf', 'dfdfdf', '', '', '', 1),
(39, 58, 25, 'iPHUN', 250000, 249999, 4, '105084656_mi phone.jpg', 'ASAS', 'ASAS', '', '', '', 1),
(40, 56, 21, 'Samsung TV dabba', 121212, 12121, 12, '105885823_crtimage.jpg', 'fbf', 'bfbfb', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `sub_categories` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `categories_id`, `sub_categories`, `status`) VALUES
(19, 56, 'LED', 1),
(20, 56, 'LCD', 1),
(21, 56, 'CRT', 1),
(22, 57, '15.6INCH', 1),
(23, 57, '14 INCH', 1),
(24, 58, 'Android', 1),
(25, 58, 'IOS', 1),
(26, 59, 'Single Door', 1),
(27, 59, 'Double Door', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(125) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `email`, `mobile`, `added_on`) VALUES
(11, 'admin', 'ASAS', 'sonalbasnet75@gmail.com', '9874563210AS', '2023-06-14 06:36:22'),
(12, 'admin', 'ASASAS', 'nepal4972@gmail.com', 'AS', '2023-06-14 06:38:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_fk_cid` (`categories_id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_fk_cid` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
