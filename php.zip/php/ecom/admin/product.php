<?php
require('top.inc.php');

if (isset($_GET['type']) && $_GET['type'] != '') {
    $type = get_safe_value($con, $_GET['type']);
    if ($type == 'status') {
        $operation = get_safe_value($con, $_GET['operation']);
        $id = get_safe_value($con, $_GET['id']);
        if ($operation == 'active') {
            $status = '1';
        } else {
            $status = '0';
        }
        $update_status_sql = "update product set status='$status' where id='$id'";
        mysqli_query($con, $update_status_sql);
    }
    if ($type == 'delete') {
        $id = get_safe_value($con, $_GET['id']);
        $delete_sql = "delete from product where id='$id'";
        mysqli_query($con, $delete_sql);
    }
}
$sql = "select product. *, categories.categories from product, categories where product.categories_id=categories.id order by product.id desc";
$res = mysqli_query($con, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Design || Future Web</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        * {
            padding: 5px;
        }

        .field_error {
            color: red;
        }

        body {
            background-color: rgb(225, 236, 172);
        }

        h1 {
            padding-bottom: 0px;
            margin-top: -20px;
            margin-bottom: 0px;
            text-align: center;
        }

        h2 {
            margin-top: 0px;
            text-align: center;
        }

        h2 a {
            display: inline-block;
            transition: background-color 0.3s, border-radius 0.3s;
            text-decoration: none;
            border-radius: 5px;
        }

        h2 a:hover {
            background-color: #4CAF50;
            color: white;
            border-radius: 50%;
        }

        .header_fixed {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ccc;
            font-size: 15px;
        }

        .table thead th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        .table tbody td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            border-right: 1px solid #ccc;
        }

        .table tbody td:last-child {
            border-right: none;
        }

        .table tbody td:first-child {
            font-weight: bold;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            color: #ffffff;
            transition: background-color 0.3s ease;
            margin-right: 5px;
        }

        .button1 {
            background-color: #1abc9c;
        }

        .button2 {
            background-color: #e67e22;
        }

        .button3 {
            background-color: #3498db;
        }

        .button:hover {
            background-color: #f10707;
        }

        .button-group {
            display: flex;
        }

        .table-container {
            display: flex;
            justify-content: center;
        }

        .imagep {
            max-width: 100%;
            height: auto;
        }
 /* Add this CSS for mobile devices */
 @media only screen and (max-width: 768px) {
        h1 {
            font-size: 24px;
        }

        h2 {
            font-size: 18px;
        }

        .table thead th,
        .table tbody td {
            font-size: 7.5px;
            padding: 5px;
        }

        .button-group {
            flex-direction: column;
            margin-top: 5px;
        }
        .button{
            padding: 4px;
            margin: 0px;
        }
    }
        
    </style>
</head>

<body>
    <br>
    <h1>Product Panel</h1>
    <h2><a href="manage_product.php">Add Product</a></h2>
    <div class="header_fixed">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Serial</th>
                        <th>ID</th>
                        <th>Categories</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Mrp</th>
                        <th>Price</th>
                        <th>QTY</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    while ($row = mysqli_fetch_assoc($res)) {
                    ?>
                        <tr>
                            <td><?php echo $i ?></td>
                            <td><?php echo $row['id'] ?></td>
                            <td><?php echo $row['categories'] ?></td>
                            <td><?php echo $row['name'] ?></td>
                            <td><img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $row['image'] ?>" class="imagep"></td>
                            <td><?php echo $row['mrp'] ?></td>
                            <td><?php echo $row['price'] ?></td>
                            <td><?php echo $row['qty'] ?></td>
                            <td>
                                <div class="button-group">
                                    <?php
                                    if ($row['status'] == 1) {
                                        echo "<span class='button button1'><a href='?type=status&operation=deactive&id=" . $row['id'] . "'>Active</a></span>&nbsp;";
                                    } else {
                                        echo "<span class='button button2'><a href='?type=status&operation=active&id=" . $row['id'] . "'>Deactive</a></span>&nbsp;";
                                    }

                                    echo "<span class='button button3'><a href='manage_product.php?id=" . $row['id'] . "'>Edit</a></span>&nbsp;";
                                    echo "<span class='button button3'><a href='?type=delete&id=" . $row['id'] . "'>Delete</a></span>&nbsp;";
                                    ?>
                                </div>
                            </td>
                        </tr>
                    <?php
                        $i++;
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

<?php
require('footer.inc.php');
?>

</html>
