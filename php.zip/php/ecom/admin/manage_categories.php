<?php
require('top.inc.php'); 
$categories='';
$msg='';
if(isset($_GET['id'])  && $_GET['id']!=''){
    $id=get_safe_value($con,$_GET['id']);
    $res=mysqli_query($con,"select * from categories where id='$id'");
    $check=mysqli_num_rows($res);
    if($check>0){
    $row=mysqli_fetch_assoc($res);
    $categories=$row['categories'];
    }else{

        header('location:categories.php');
    die();
    }
}

if(isset($_POST['submit'])){
    $categories=get_safe_value ($con,$_POST['categories']);
    $res=mysqli_query($con,"select * from categories where categories='$categories'");
    $check=mysqli_num_rows($res);
    if($check>0){
        if(isset($_GET['id'])  && $_GET['id']!=''){
            $getData=mysqli_fetch_assoc($res);
            if($id==$getData['id']){

            }else{
                $msg=" categories already exists";
            }
        }else{
        $msg=" categories already exists";
        }
    }
if($msg==''){
    
        if(isset($_GET['id'])  && $_GET['id']!=''){
            mysqli_query($con,"update categories set categories='$categories' where id='$id'");
        }else{
        mysqli_query($con,"insert into categories(categories,status) values('$categories','1')");
        }
        header('location:categories.php');
        die();
    }
}



?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Categories</title>
  <link rel="stylesheet" type="text/css" href="manage_categories.css">
</head>
<body>
  <h1> Update or Add New Categories Here</h1>
  <div class="container">
  <form method="post" class="form">
    <table>
      <thead>
        <tr>
          <th>Enter Categories</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><input type="text" name="categories" placeholder="Enter categories" value="<?php echo $categories ?>" class="input-field" required></td>
        </tr>
      </tbody>
    </table>
    <input type="submit" name="submit" value="Submit" class="submit-btn">
    <div class="field_error"><?php echo $msg ?></div>
  </form>
</div>
<?php
require('footer.inc.php');?>
</body>

</html>
