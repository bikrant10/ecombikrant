<?php
require('top.php');?>
<!DOCTYPE html>
<html>
<head>
    <title>Divisions Example</title>
    <link rel="stylesheet" href="checkout.css">
    
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />


</head>
<body>
    <div class="container">
        <div class="left-container">
            <h2 class="toglee">
                <span id="toggle1" class="toggle-button" onclick="toggleDivision(1)"></span> Login and Register
            </h2>
            <div id="division1" class="hidden">
    <div class="form-container">
        <div class="login-form">
            <h3>Login</h3>
            <form>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                
                <button type="submit">Login</button>
            </form>
        </div>

        <div class="register-form">
            <h3>Register</h3>
            <form>
                <label for="newUsername">Username:</label>
                <input type="text" id="newUsername" name="newUsername" required>
                
                <label for="newPassword">Password:</label>
                <input type="password" id="newPassword" name="newPassword" required>
                
                <label for="confirmPassword">Confirm Password:</label>
                <input type="password" id="confirmPassword" name="confirmPassword" required>
                
                <button type="submit">Register</button>
            </form>
        </div>
    </div>
</div>

            
            
            <h2 class="toglee">
                <span id="toggle2" class="toggle-button" onclick="toggleDivision(2)"></span> Address Information
            </h2>
            <div id="division2" class="hidden">
    <h3>Add Address Information</h3>
    <form onsubmit="return validateForm()">
    <label for="state">State:</label>
        <input type="text" id="state" name="state" required>
        <label for="city">City:</label>
        <input type="text" id="city" name="city" required>

        <label for="street">Street:</label>
        <input type="text" id="street" name="street" required><br>
        <label for="pnumber">Phone Number:</label>
        <input type="tel" id="pnumber" name="pnumber" pattern="[1-9]{1}[0-9]{9}" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
      

        
       

        <button type="submit">Submit</button>
    </form>
</div>
            
            <h2 class="toglee">
                <span id="toggle3" class="toggle-button" onclick="toggleDivision(3)"></span> Left Division 3
            </h2>
            <div id="division3" class="hidden">
                <p>This is the content of Left Division 3.</p>
            </div>
        </div>
        <div class="right-container">
    <div class="right">
        <h2>Order Details</h2>
        <table class="luffy">
            <tr>
                <th>Image</th>
                <th>Product Name</th>
                <th>Price</th>
                <th></th>
            </tr>
            <tr>
                <td><img src="tv.jpg" alt="Product Image"></td>
                <td>Product 1</td>
                <td>$99.00</td>
                <td><span class="remove-icon"><i class="fas fa-times"></i></span></td>
            </tr>
            <tr>
                <td><img src="tv.jpg" alt="Product Image"></td>
                <td>Product 2</td>
                <td>$199.00</td>
                <td><span class="remove-icon"><i class="fas fa-times"></i></span></td>
            </tr>
        </table>

        <div class="order-summary">
            <table>
                <tr>
                    <td>Subtotal</td>
                    <td>$909.00</td>
                </tr>
                <tr>
                    <td>Tax</td>
                    <td>$9.00</td>
                </tr>
                <tr>
                    <td>Order Total</td>
                    <td>$918.00</td>
                </tr>
            </table>
        </div>
    </div>
</div>


    </div>

    <script>
        function toggleDivision(divisionNumber) {
    var division = document.getElementById("division" + divisionNumber);
    var toggle = document.getElementById("toggle" + divisionNumber);
    var isOpen = !division.classList.contains("hidden");

    // Close all divisions
    var divisions = document.querySelectorAll(".left-container > div");
    for (var i = 0; i < divisions.length; i++) {
        divisions[i].classList.add("hidden");
    }

    // Remove "open" class from all toggle buttons
    var toggleButtons = document.getElementsByClassName("toggle-button");
    for (var i = 0; i < toggleButtons.length; i++) {
        toggleButtons[i].classList.remove("open");
    }

    // Open the clicked division if it was previously closed
    if (!isOpen) {
        division.classList.remove("hidden");
        toggle.classList.add("open");
    }
}


// FORM INVALID WORD JS

function validateForm() {
        // var restrictedWords = ["Madhesh Pradesh", "restricted", "forbidden"]; // Restricted words
       
        var acceptedCityWords = ["BRT", "BIRATNAGAR", "biratnagar", "Biratnagar"]; // Accepted words for city
        var acceptedStateWords = ["Pradesh 1", "1", "Koshi Pradesh","Koshi"]; // Accepted words for state

        var streetInput = document.getElementById("street").value;
        var cityInput = document.getElementById("city").value;
        var stateInput = document.getElementById("state").value;

        // if (containsRestrictedWord(streetInput, restrictedWords)) {
        //     alert("Invalid street input. Please avoid using restricted words.");
        //     return false;
        // }

       

        if (!containsAcceptedWord(cityInput, acceptedCityWords)) {
            alert("Currently we are operating in Biratnagar Only");
            return false;
        }

        if (!containsAcceptedWord(stateInput, acceptedStateWords)) {
            alert("Sorry we only operate in Koshi Pradesh");
            return false;
        }

        return true;
    }

    function containsRestrictedWord(input, restrictedWords) {
        for (var i = 0; i < restrictedWords.length; i++) {
            if (input.toLowerCase().includes(restrictedWords[i].toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    function containsAcceptedWord(input, acceptedWords) {
        for (var i = 0; i < acceptedWords.length; i++) {
            if (input.toLowerCase().includes(acceptedWords[i].toLowerCase())) {
                return true;
            }
        }
        return false;
    }
    </script>
</body>
<?php
require('footer.php');?>
</html>
