<?php
require('top.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="wishlist.css">
    <title>Document</title>
</head>
<body>
<div class="table-container">
<table class="wishlist-table">
  <thead>
    <tr>
      <th>Remove</th>
      <th>Image</th>
      <th>Product Name</th>
      <th>Unit Price</th>
      <th>Stock Status</th>
      <th>Add To Cart</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><button class="remove-button">Remove</button></td>
      <td><img src="tv.jpg" alt="Product 1"  class="a12"></td>
      <td>Product 1</td>
      <td>$10.00</td>
      <td>In Stock</td>
      <td><button class="add-to-cart-button">Add to Cart</button></td>
    </tr>
    <tr>
      <td><button class="remove-button">Remove</button></td>
      <td><img src="tv.jpg" alt="Product 2" class="a12"></td>
      <td>Product 2</td>
      <td>$15.00</td>
      <td>In Stock</td>
      <td><button class="add-to-cart-button">Add to Cart</button></td>
    </tr>
    <tr>
      <td><button class="remove-button">Remove</button></td>
      <td><img src="tv.jpg" alt="Product 2" class="a12"></td>
      <td>Product 2</td>
      <td>$15.00</td>
      <td>In Stock</td>
      <td><button class="add-to-cart-button">Add to Cart</button></td>
    </tr>
    <tr>
      <td><button class="remove-button">Remove</button></td>
      <td><img src="tv.jpg" alt="Product 2" class="a12"></td>
      <td>Product 2</td>
      <td>$15.00</td>
      <td>In Stock</td>
      <td><button class="add-to-cart-button">Add to Cart</button></td>
    </tr>
    <tr>
      <td><button class="remove-button">Remove</button></td>
      <td><img src="tv.jpg" alt="Product 2" class="a12"></td>
      <td>Product 2</td>
      <td>$15.00</td>
      <td>In Stock</td>
      <td><button class="add-to-cart-button">Add to Cart</button></td>
    </tr>
    <tr>
      <td><button class="remove-button">Remove</button></td>
      <td><img src="tv.jpg" alt="Product 2" class="a12"></td>
      <td>Product 2</td>
      <td>$15.00</td>
      <td>In Stock</td>
      <td><button class="add-to-cart-button">Add to Cart</button></td>
    </tr>
    <!-- Add more rows for other wishlist items -->
  </tbody>
</table>
</div>
</body>
<?php
require('footer.php');?>
</html>