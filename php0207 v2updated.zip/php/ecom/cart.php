<?php
require('top.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="cart.css">
    <title>Document</title>
</head>
<body>
<div class="shopping-cart">
  <table>
    <thead>
      <tr class="tr">
        <th>PRODUCTS IMAGE</th>
        <th>NAME OF PRODUCTS</th>
        <th>MRP</th>
        <th>PRICE</th>
        <th>QUANTITY</th>
        <th>TOTAL</th>
        <th>REMOVE</th>
      </tr>
    </thead>
    <tbody>
    <?php
										if(isset($_SESSION['cart'])){
											foreach($_SESSION['cart'] as $key=>$val){
											$productArr=get_product($con,'','',$key);
											$pname=$productArr[0]['name'];
											$mrp=$productArr[0]['mrp'];
											$price=$productArr[0]['price'];
											$image=$productArr[0]['image'];
											$qty=$val['qty'];
											?>
      <tr class="tr">
        <td class="op"><img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$image?>"  /></td>
        <td><?php echo $pname?></td>
        <td><?php echo $mrp?></td>
        <td><?php echo $price?></td>

        <td>
          <div class="quantity">
           
          <input type="number" id="<?php echo $key?>qty" value="<?php echo $qty?>" />
            <a href="javascript:void(0)" onclick="manage_cart('<?php echo $key?>','update')">update</a>
          
          </div>
        </td>
        <td><?php echo $qty*$price?></td>
        <td><button type="button"><a href="javascript:void(0)" onclick="manage_cart('<?php echo $key?>','remove')">REMOVE</a></button></td>
      </tr>
      <?php } }?>
    </tbody>
  </table>

  <div class="cart-buttons">
    <button class="continue-shopping"> <a href="<?php echo SITE_PATH?>" class="continue">Continue Shopping</a></button>
    <div class="update-checkout">
      <button class="checkout"><a href="<?php echo SITE_PATH?>checkout.php" class="continue">Checkout</a></button>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
  function manage_cart(pid,type){
	if(type=='update'){
		var qty=jQuery("#"+pid+"qty").val();
	}else{
		var qty=jQuery("#qty").val();
	}
	jQuery.ajax({
		url:'manage_cart.php',
		type:'post',
		data:'pid='+pid+'&qty='+qty+'&type='+type,
		success:function(result){
			if(type=='update' || type=='remove'){
				window.location.href='cart.php';
			}
			jQuery('.htc__qua').html(result);
		}	
	});	
}

</script>
    
</body>
<?php
require('footer.php');?>
</html>