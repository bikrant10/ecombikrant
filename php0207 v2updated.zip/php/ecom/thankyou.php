<?php 
require('top.php');
?>
THANKS
        						
<?php require('footer.php')?>        