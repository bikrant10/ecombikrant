<?php
require('top.php');
if (!isset($_SESSION['USER_LOGIN'])) {
    ?>
    <script>
        window.location.href = 'index.php';
    </script>
    <?php
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            box-sizing: border-box;
        }

        .wishlist-table {
            width: 100%;
            border-collapse: collapse;
            text-align: center;
            /* Add this line */
        }

        .wishlist-table th,
        .wishlist-table td {
            padding: 5px;
            border: 1px solid rgb(148, 136, 136);
            text-align: center;
            /* Add this line */
        }

        .wishlist-table th {
            background-color: #f2f2f2;
        }

        .remove-button,
        .add-to-cart-button {
            background-color: #ff0000;
            color: #fff;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        .add-to-cart-button {
            background-color: #008000;
        }

        .a12 {

            width: 92px;
            height: 122px;

        }

        .table-container {
            padding: 100px 50px 150px 50px;


        }
    </style>
</head>

<body>
    <div class="table-container">
        <table class="wishlist-table">
            <thead>
                <tr>
                    <th>NAME</th>
                    <th>ORDER DATE</th>
                    <th>ADDRESS</th>
                    <th>PAYMENT TYPE</th>
                    <th>ORDER STATUS</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $uid = $_SESSION['USER_ID'];
                $res = mysqli_query($con, "select `order`.*,order_status.name as order_status_str from `order`,order_status where `order`.user_id='$uid' and order_status.id=`order`.order_status");
                while ($row = mysqli_fetch_assoc($res)) {
                    ?>
                    <tr>
                        <td><button class="remove-button">
                                <a href="my_order_details.php?id=<?php echo $row['id'] ?>"> <?php echo $row['id'] ?></a>
                            </button></td>
                        <!-- <td><img src="tv.jpg" alt="Product 1" class="a12"></td> -->
                        <td>
                            <?php echo $row['added_on'] ?>
                        </td>
                        <td>
                            <?php echo $row['address'] ?><br />
                            <?php echo $row['city'] ?><br />
                            <?php echo $row['pincode'] ?>
                        </td>
                        <td>
                            <?php echo $row['payment_type'] ?>
                        </td>
                        <td>
                        <?php echo $row['order_status_str']?>
                        </td>
                    </tr>

                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
<?php
require('footer.php'); ?>

</html>