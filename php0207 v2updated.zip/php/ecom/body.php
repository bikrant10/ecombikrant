<?php
require('top.php'); ?>
<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="body.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    
</head>

<body>


  <main>
    <!-- <section class="new-arrivals">
      <h2>New Arrivals</h2>
      <p class="abc">Product we added in stock recently</p>
      <?php
      $get_product = get_product($con, 4);
      foreach ($get_product as $list) {


        ?>

      <div class="product-grid">
        <div class="product">
          <div class="product-image">
            <img src="tv.jpg" alt="Product 1" class="a1">
            <div class="product-info">
            <h5><a href="product_details.php"><?php echo $list['name'] ?></a></h5>
            <ul class="info">
              <li class="oldprice"><?php echo $list['mrp'] ?></li>
              <li><?php echo $list['price'] ?></li>
      </ul>
              
            
            
            </div>
          </div>
        </div>
      </div>
      <?php } ?>
    </section> -->
    <section class="new-arrivals">
      <h2>New Arrivals</h2>
      <p class="abc">Products we added to stock recently</p>

      <div class="product-grid">
        <?php
        $get_product = get_product($con, 4);
        foreach ($get_product as $list) {
          ?>
          <div class="product">
            <div class="product-image">
              <div class="image-container">
                <img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $list['image'] ?>" alt="Product 1" class="a1">
                <a href="javascript:void(0)" onclick="wishlist_manage('<?php echo $list['id']?>','add')"><i class="wishlist-icon far fa-heart"></i></a>
              </div>
              
              <div class="product-info">
                <h5><a href="product_details.php?id=<?php echo $list['id'] ?>"><?php echo $list['name'] ?></a></h5>
                <ul class="info">
                  <li class="oldprice">
                    <?php echo $list['mrp'] ?>
                  </li>
                  <li>
                    <?php echo $list['price'] ?>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>


    </section>

  </main>
  <main>
    <section class="new-arrivals">
      <h2>Best Seller</h2>
      <p class="abc">Product we added in stock recently</p>
      <div class="product-grid">
        <?php
        $get_product = get_product($con,4,'','','yes');
        foreach ($get_product as $list) {
          ?>
          <div class="product">
            <div class="product-image">
              <div class="image-container">
                <img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $list['image'] ?>" alt="Product 1" class="a1">
                <a href="javascript:void(0)" onclick="wishlist_manage('<?php echo $list['id']?>','add')"><i class="wishlist-icon far fa-heart"></i></a>
              </div>
              
              <div class="product-info">
                <h5><a href="product_details.php?id=<?php echo $list['id'] ?>"><?php echo $list['name'] ?></a></h5>
                <ul class="info">
                  <li class="oldprice">
                    <?php echo $list['mrp'] ?>
                  </li>
                  <li>
                    <?php echo $list['price'] ?>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>



      </div>

      </div>
    </section>
  </main>

  <!-- <script>
document.addEventListener("DOMContentLoaded", function() {
  const imageContainers = document.querySelectorAll(".image-container");

  imageContainers.forEach(function(container) {
    const wishlistIcon = container.querySelector(".wishlist-icon");

    container.addEventListener("mouseenter", function() {
      wishlistIcon.style.opacity = 1;
    });

    container.addEventListener("mouseleave", function() {
      if (!wishlistIcon.classList.contains("selected")) {
        wishlistIcon.style.opacity = 0;
      }
    });

    wishlistIcon.addEventListener("click", function() {
      wishlistIcon.classList.toggle("selected");
      container.classList.toggle("disable-hover");
    });
  });
});

  </script> -->




  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script>

function wishlist_manage(pid,type){
	jQuery.ajax({
		url:'wishlist_manage.php',
		type:'post',
		data:'pid='+pid+'&type='+type,
		success:function(result){
			if(result=='not_login'){
				window.location.href='login_register.php';
			}else{
				jQuery('.hello').html(result);
			}
		}	
	});	
}
  </script>
</body>
<?php
require('footer.php'); ?>

</html>