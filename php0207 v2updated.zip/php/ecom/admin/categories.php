<?php
require('top.inc.php'); 

if(isset($_GET['type']) && $_GET['type']!=''){
    $type=get_safe_value($con,$_GET['type']);
    if($type=='status'){
        $operation=get_safe_value($con,$_GET['operation']);
        $id=get_safe_value($con,$_GET['id']);
        if($operation=='active'){
            $status='1';
        }else{
            $status='0';
        }
        $update_status_sql="update categories set status='$status' where id='$id'";
        mysqli_query($con,$update_status_sql);
    }
    if($type=='delete'){
        $id=get_safe_value($con,$_GET['id']);
        $delete_sql="delete from categories where id='$id'";
        mysqli_query($con,$delete_sql);
    }
}
$sql="select * from categories order by categories asc";
$res=mysqli_query($con,$sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Design || Future Web</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        * {
            padding: 5px;
        }

        body {
            background-color: rgb(225, 236, 172);
        }

        h1 {
            padding-bottom: 0px;
            margin-bottom: 0px;
            text-align: center;
        }

        h2 {
            margin-top: 0px;
            text-align: center;
        }

        h2 a {
            display: inline-block;
            transition: background-color 0.3s, border-radius 0.3s;
            text-decoration: none;
            border-radius: 5px;
        }

        h2 a:hover {
            background-color: #4CAF50;
            color: white;
            border-radius: 50%;
        }

        /* CODE FOR TABLE */

        .header_fixed {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ccc;
        }

        .table thead th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        .table tbody td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            border-right: 1px solid #ccc;
        }

        .table tbody td:last-child {
            border-right: none;
        }

        .table tbody td:first-child {
            font-weight: bold;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            color: #ffffff;
            transition: background-color 0.3s ease;
        }

        .button1 {
            background-color: #1abc9c;
        }

        .button2 {
            background-color: #e67e22;
        }

        .button3 {
            background-color: #3498db;
        }

        .button:hover {
            background-color: #f10707;
        }

        /* Responsive Styles */

        @media screen and (max-width: 768px) {
  .header_fixed {
    padding: 10px;
  }

  .table thead th,
  .table tbody td {
    padding: 5px;
  }

  .button-container {
    flex-wrap: nowrap; 
    overflow: auto; 
    white-space: nowrap; 
  }
}


        @media screen and (max-width: 480px) {
            .table thead th,
            .table tbody td {
                font-size: 10px;
            }
            .button {
                padding: 2px 5px;
                font-size: 10px;
            }
        }
    </style>

</head>

<body>
    <h1>Categories</h1>
    <h2><a href="manage_categories.php">Add Categories</a></h2>
    <div class="header_fixed">
        <table class="table">
            <thead>
                <tr>
                    <th>Serial</th>
                    <th>ID</th>
                    <th>Categories</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                while ($row = mysqli_fetch_assoc($res)) { ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['id'] ?></td>
                        <td><?php echo $row['categories'] ?></td>
                        <td>
                            <div class="button-container">
                                <?php
                                if ($row['status'] == 1) {
                                    echo "<span class='button button1'><a href='?type=status&operation=deactive&id=" . $row['id'] . "'>Active</a></span>&nbsp;";
                                } else {
                                    echo "<span class='button button2'><a href='?type=status&operation=active&id=" . $row['id'] . "'>Deactive</a></span>&nbsp;";
                                }

                                echo "<span class='button button3'><a href='manage_categories.php?id=" . $row['id'] . "'>Edit</a></span>&nbsp;";
                                echo "<span class='button button3'><a href='?type=delete&id=" . $row['id'] . "'>Delete</a></span>&nbsp;";
                                ?>
                            </div>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>

<?php
require('footer.inc.php');
?>

</html>
