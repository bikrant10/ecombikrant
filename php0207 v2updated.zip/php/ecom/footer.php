
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<style>
  *{
  box-sizing: border-box;
} 
footer {
    background-color: black;
    color: white;
    padding: 20px;
    
  height: 225px;

  }

  .footer-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .about-us {
    width: 30%;
  }

  .social-icons a {
    color: white;
    text-decoration: none;
    margin-right: 10px;
  }

  .information {
    width: 40%;
  }

  .information h3 {
    color: white;
  }

  .subcategories a {
    color: white;
    text-decoration: none;
    margin-left: 170px;
  }

  .newsletter {
    width: 30%;
  }

  input[type="email"] {
    width: 80%;
    padding: 5px;
  }

  button[type="submit"] {
    padding: 5px 10px;
    background-color: #000;
    color: #fff;
    border: none;
  }

  .copyright {
    text-align: center;
    margin-top: 20px;
  }
  p{
      
  margin-top: 0px;
  margin-bottom: 0px;
  
  padding-bottom: 10px;


  }
  .A1{
      margin: 0px 0px 0px 20px;
      
  padding-bottom: 10px;

  }
  .A2{
      margin: 0px;
      margin-left: 170px;
      
  padding-bottom: 10px;
  
  margin-top: -28px;


  }
  .A3{
      margin: 0px;
  }
  @media (max-width: 767px) {
  .footer-section {
    flex-wrap: wrap;
  }

  .about-us, .information, .newsletter {
    width: 100%;
    max-width: 100%;
    margin-bottom: 20px;
  }

  .subcategories a {
    margin-left: 0;
    margin-bottom: 5px;
  }

  .A2 {
    margin-left: 0;
    margin-top: 0;
  }
  footer{
    height: 100%;
    width: 368px;
  }
}
</style>
 
</head>
<body>
  <footer>
    <div class="footer-section">
      <div class="about-us">
        <h3 class="A1">About Us</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem magnam ratione suscipit ea ut, voluptate vero quis incidunt sequi debitis.

        </p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-linkedin-in"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
      </div>

      <div class="information">
        <h3  class="A2">MY ACCOUNT</h3>
        <div class="subcategories">
          <a href="link1.html">My Account</a><br>
          <a href="cart.php">My Cart</a><br>
          <a href="link3.html">Login</a><br>
          <a href="wishlist.php">Wishlist</a><br>
          <a href="checkout.php">Checkout</a><br>
        </div>
      </div>

      <div class="newsletter">
    <h3  class="A3">newsletter</h3>
        <input type="email" placeholder="Enter your email address">
        <button type="submit">Subscribe</button>
      </div>
    </div>

    <div class="copyright">
      <p>&copy; Bikrant 2023. All Rights Reserved.</p>
    </div>
  </footer>
</body>
</html>
