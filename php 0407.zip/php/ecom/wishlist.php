<?php
require('top.php');
if (!isset($_SESSION['USER_LOGIN'])) {
  ?>
  <script>
    window.location.href = 'index.php';
  </script>
  <?php
}
$uid = $_SESSION['USER_ID'];

$res = mysqli_query($con, "select product.name,product.image,product.price,product.mrp,wishlist.id from product,wishlist where wishlist.product_id=product.id and wishlist.user_id='$uid'");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="wishlist.css">
  <title>Document</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
  <div class="table-container">
    <table class="wishlist-table">
      <thead>
        <tr>
          <th class="product-thumbnail">products</th>
          <th class="product-name">name of products</th>
          <th class="product-name">price</th>
          <th class="product-remove">Remove</th>
        </tr>
      </thead>
      <tbody>
        <?php
        while ($row = mysqli_fetch_assoc($res)) {
          ?>
          <tr>
            <td><img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $row['image'] ?>" />
            </td>
            <td>
              <?php echo $row['name'] ?>

            </td>
            <td>
              <?php echo $row['price'] ?>

            </td>

            <td><a href="wishlist.php?wishlist_id=<?php echo $row['id'] ?>"><i class="fa fa-trash"
                  aria-hidden="true"></i></a></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
   
  </script>
</body>
<?php
require('footer.php'); ?>

</html>