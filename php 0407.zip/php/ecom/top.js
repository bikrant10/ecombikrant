var prevScrollpos = window.pageYOffset;
var navbar = document.querySelector(".navbar");

window.onscroll = function() {
  var currentScrollPos = window.pageYOffset;
  
  if (prevScrollpos > currentScrollPos) {
    navbar.style.top = "0";
    navbar.classList.remove("scrolled");
  } else {
    navbar.style.top = "-100px";
    navbar.classList.add("scrolled");
  }
  
  prevScrollpos = currentScrollPos;
};

setTimeout(function() {
  navbar.style.top = "-100px";
}, 1000);
