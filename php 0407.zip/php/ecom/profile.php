<?php 
require('top.php');
if(!isset($_SESSION['USER_LOGIN'])){
	?>
	<script>
	window.location.href='index.php';
	</script>
	<?php
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Login and Register Forms</title>
  <link rel="stylesheet" href="login_register.css">
 
</head>
<body>
  <div class="container">
    <div class="hello" id="login1">
      <h2>PROFILE</h2>
      <form method="POST" id="login">
        
        <input type="text" id="name" name="name" placeholder="Enter your name" required value="<?php echo $_SESSION['USER_NAME']?>">
      <span class="field_error" id="name_error"></span><br>
        <button type="button" onclick="update_profile()" id="btn_submit">UPDATE</button>
		<p>Forget password?</p>


        
      </form>
      <div class="output">
        <p class="messege field_error "></p>
      </div>
    </div>
    <div class="hello" id="register1">
      <h2>CHANGE PASSWORD</h2>
      <form method="POST" id="register">
      <input type="password" name="current_password" id="current_password" >
      <span class="field_error" id="current_password_error"></span>

 
  <input type="password" name="new_password" id="new_password" >
  <span class="field_error" id="new_password_error"></span>




  <input type="password" name="confirm_new_password" id="confirm_new_password">
  <span class="field_error" id="confirm_new_password_error"></span>

  <button type="button" onclick="update_password()" id="btn_update_password">UPDATE</button>
</form>


      <div class="output">
        <p class="messege field_error "></p>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
  function update_profile(){
			jQuery('.field_error').html('');
			var name=jQuery('#name').val();
			if(name==''){
				jQuery('#name_error').html('Please enter your name');
			}else{
				jQuery('#btn_submit').html('Please wait...');
				jQuery('#btn_submit').attr('disabled',true);
				jQuery.ajax({
					url:'update_profile.php',
					type:'post',
					data:'name='+name,
					success:function(result){
            
						jQuery('#name_error').html(result);
						jQuery('#btn_submit').html('Update');
						jQuery('#btn_submit').attr('disabled',false);
					}
				})
			}
		}
    function update_password(){
			jQuery('.field_error').html('');
			var current_password=jQuery('#current_password').val();
			var new_password=jQuery('#new_password').val();
			var confirm_new_password=jQuery('#confirm_new_password').val();
			var is_error='';
			if(current_password==''){
				jQuery('#current_password_error').html('Please enter password');
				is_error='yes';
			}if(new_password==''){
				jQuery('#new_password_error').html('Please enter password');
				is_error='yes';
			}if(confirm_new_password==''){
				jQuery('#confirm_new_password_error').html('Please enter password');
				is_error='yes';
			}
			
			if(new_password!='' && confirm_new_password!='' && new_password!=confirm_new_password){
				jQuery('#confirm_new_password_error').html('Please enter same password');
				is_error='yes';
			}
			
			if(is_error==''){
				jQuery('#btn_update_password').html('Please wait...');
				jQuery('#btn_update_password').attr('disabled',true);
				jQuery.ajax({
					url:'update_password.php',
					type:'post',
					data:'current_password='+current_password+'&new_password='+new_password,
					success:function(result){
            jQuery('#current_password').val('');
            jQuery('#new_password').val('');
            jQuery('#confirm_new_password').val('');
						jQuery('#current_password_error').html(result);
						jQuery('#btn_update_password').html('Update');
						jQuery('#btn_update_password').attr('disabled',false);
						jQuery('#frmPassword')[0].reset();
					}
				})
			}
			
		}
  </script>
</body>
 <?php require('footer.php'); ?>
</html>