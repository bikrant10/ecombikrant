<?php
require('connection.inc.php');
require('function.inc.php');
$msg='';
if(isset($_POST['submit'])){
    $username = get_safe_value($con, $_POST['username']);
    $password = get_safe_value($con, $_POST['password']);
    $sql = "SELECT * FROM admin_users WHERE username='$username' AND password='$password'";
    $res = mysqli_query($con, $sql);
    $count = mysqli_num_rows($res);
    if($count > 0){
        $_SESSION['ADMIN_LOGIN'] = 'yes';
        $_SESSION['ADMIN_USERNAME'] = $username;
        header('location:categories.php');
        die();
    } else{
        $msg = "Enter correct login details";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN LOGIN</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #6abadeba;
            font-family: 'Arial';
        }
        
        div.login {
            width: 300px;
            overflow: hidden;
            margin: auto;
            margin: 20 0 0 450px;
            padding: 80px;
            background: #f36405;
            border-radius: 15px;
        }
        
        h2 {
            text-align: center;
            color: #277582;
            padding: 20px;
        }
        
        label {
            color: #08ffd1;
            font-size: 17px;
        }
        
        #Uname,
        #Pass,
        #log {
            width: 100%;
            height: 30px;
            border: none;
            border-radius: 3px;
            padding-left: 8px;
        }
        
        #log {
            background-color: blue;
            color: white;
        }
        
        .field_error {
            color: red;
        }
        
        @media (max-width: 768px) {
            div.login {
                width: 80%;
                margin: 20px auto;
                padding: 40px;
            }
        }
        
        @media (max-width: 480px) {
            div.login {
                width: 90%;
                margin: 20px auto;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <h2>Login</h2><br>
    <div class="login">
        <form id="login" method="post">
            <label><b>User Name</b></label>
            <input type="text" name="username" id="Uname" placeholder="Username" required>
            <br><br>
            <label><b>Password</b></label>
            <input type="Password" name="password" id="Pass" placeholder="Password" required>
            <br><br>
            <button type="submit" name="submit" id="log">Login In</button>
            <br><br>
            <div class="field_error"><?php echo $msg?></div>
        </form>
    </div>
</body>
<?php
require('footer.inc.php');
?>
</html>
