<?php
require('top.inc.php'); 

if(isset($_GET['type']) && $_GET['type']!=''){
    $type=get_safe_value($con,$_GET['type']);
    
    if($type=='delete'){
        
        $id=get_safe_value($con,$_GET['id']);
        
        $delete_sql="delete from users where id='$id'";
        mysqli_query($con,$delete_sql);
    }
}
$sql="select * from  users order by id desc";
$res=mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Design || Future Web</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        * {
            padding: 5px;
        }

        .field_error {
            color: red;
        }

        body {
            background-color: rgb(225, 236, 172);
        }

        h1 {
            padding-bottom: 0px;
            margin-top: -20px;
            margin-bottom: 0px;
            text-align: center;
        }

        /* TABEL KO PART HO HAI */
        .header_fixed {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ccc;
        }

        .table thead th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        .table tbody td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            border-right: 1px solid #ccc;
        }

        .table tbody td:last-child {
            border-right: none;
        }

        .table tbody td:first-child {
            font-weight: bold;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            color: #ffffff;
            transition: background-color 0.3s ease;
        }

        .button3 {
            background-color: #1abc9c;
        }

        .button:hover {
            background-color: #f10707;
        }

        @media  only screen and (max-width: 768px) {
            h1 {
                font-size: 24px;
            }

            .header_fixed {
                padding: 10px 0px 10px 0px;
            }

            .table {
                font-size: 7px;
              
            }

            .table thead th,
            .table tbody td {
                padding: 5px;
            }

            .button {
                padding: 5px 0px 5px 0px;
            }
            
        }
       
    </style>

</head>

<body>
    <br>
    <h1>Users</h1>

    <div class="header_fixed">
        <table class="table">
            <thead>
                <tr>
                    <th>Serial</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>Date</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                while ($row = mysqli_fetch_assoc($res)) {
                ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['id'] ?></td>
                        <td><?php echo $row['name'] ?></td>
                        <td><?php echo $row['email'] ?></td>
                        <td><?php echo $row['mobile'] ?></td>
                        <td><?php echo $row['added_on'] ?></td>
                        <td>
                            <div class="button-group">
                                <?php
                                echo "<span class='button button3'><a href='?type=delete&id=" . $row['id'] . "'>Delete</a></span>&nbsp;";
                                ?>
                            </div>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>

<?php
require('footer.inc.php');
?>

</html>
