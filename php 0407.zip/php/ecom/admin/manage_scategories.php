<?php
require('top.inc.php');
$categories = '';
$msg = '';
if (isset($_GET['id']) && $_GET['id'] != '') {
  $id = get_safe_value($con, $_GET['id']);
  $res = mysqli_query($con, "select * from sub_categories where id='$id'");
  $check = mysqli_num_rows($res);
  if ($check > 0) {
    $row = mysqli_fetch_assoc($res);
    $sub_categories = $row['sub_categories'];
    $categories = $row['categories_id'];
    ;
  } else {

    header('location:sub_categories.php');
    die();
  }
}

if (isset($_POST['submit'])) {
  $categories = get_safe_value($con, $_POST['categories_id']);
  $sub_categories = get_safe_value($con, $_POST['sub_categories']);
  $res = mysqli_query($con, "select * from sub_categories where categories_id='$categories' and sub_categories='$sub_categories'");
  $check = mysqli_num_rows($res);
  if ($check > 0) {
    if (isset($_GET['id']) && $_GET['id'] != '') {
      $getData = mysqli_fetch_assoc($res);
      if ($id == $getData['id']) {

      } else {
        $msg = " subcategories already exists";
      }
    } else {
      $msg = " subcategories already exists";
    }
  }
  if ($msg == '') {
    if (isset($_GET['id']) && $_GET['id'] != '') {
      mysqli_query($con, "update sub_categories set categories_id='$categories',sub_categories='$sub_categories' where id='$id'");
    } else {

      mysqli_query($con, "insert into sub_categories(categories_id,sub_categories,status) values('$categories','$sub_categories','1')");
    }
    header('location:sub_categories.php');
    die();
  }
}
?>
<!DOCTYPE html>
<html>

<head>
  <title>Manage Categories</title>

  <style>
    * {
      padding: 5px;
    }

    .field_error {
      color: red;
    }

    body {
      background-color: rgb(225, 236, 172);
    }

    h1 {
      padding-bottom: 0px;
      margin-bottom: 0px;
      text-align: center;
    }

    .container {
      display: flex;
      justify-content: center;
      align-items: center;
      /* height: 60vh; Added to vertically center the form */
    }

    .form1 {
      border: 1px solid #ccc;
      padding: 40px;
      border-radius: 10px;
      background-color: #f5f5f5;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      width: 100%;
    }

    .form1 label,
    .form1 input,
    .form1 select {
      display: block;
      margin-bottom: 10px;
      width: 100%;
    }
    .form1 button {
      display: block;
      margin-bottom: 10px;
     
    }
    .form1 button {
      text-align: center;
    }

    .form1 .card-header {
      text-align: center;
      font-size: 20px;
    }

    .form1 .field_error {
      margin-top: 10px;
      text-align: center;
    }
    .form-control,
    .select{
      padding: 12px;
        width: 100%;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
  /* code for submit button */
  .btn {
    padding: 8px 16px; 
    display: block;
    margin: 0 auto;
    box-sizing: border-box;
    border: none;
    border-radius: 5px;
    background-color: #6b09eb;
    color: #e0e407;
    cursor: pointer;
    font-family: Arial, sans-serif;
    transition: all 0.3s;
    position: relative;
    overflow: hidden;

  }
  
  .btn:before {
    content: '';
    position: absolute;
    top: 0;
  
    background-color: #0b49f3;
    transition: all 0.3s;
  }
  
  .btn:hover:before {
    left: 0;
  }
  
  .btn:hover {
    background-color: #23527c;
    color: #0de956;
  }
 
  </style>
</head>

<body>
  <h1> Update or Add New Sub-Categories Here</h1>
  <div class="container">
    <form method="post" class="form1">
      
      <label for="categories" style="text-align: center;"><strong>SELECT CATEGORIES</strong></label>
      <select name="categories_id" class="select" required>
        <option value="">Select Categories</option>
        <?php
        $res = mysqli_query($con, "select * from categories where status='1'");
        while ($row = mysqli_fetch_assoc($res)) {
          if ($row['id'] == $categories) {
            echo "<option value=" . $row['id'] . " selected>" . $row['categories'] . "</option>";
          } else {
            echo "<option value=" . $row['id'] . ">" . $row['categories'] . "</option>";
          }
        }
        ?>
      </select>

      <div>
        <label for="categories" style="text-align: center;"><strong>ENTER SUB CATEGORIES</strong></label>
        <input type="text" name="sub_categories" placeholder="Enter sub categories" class="form-control" required>
      </div>
      <button id="payment-button" name="submit" type="submit" class="btn">
        <span id="payment-button-amount">Submit</span>
      </button>
      <div class="field_error">
        <?php echo $msg ?>
      </div>



    </form>
  </div>
  <?php
  require('footer.inc.php'); ?>
</body>


</html>