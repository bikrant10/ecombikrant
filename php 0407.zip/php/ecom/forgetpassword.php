<?php 

require('top.php'); 

?> 
<!DOCTYPE html>
<html>
<head>
  <title>Login and Register Forms</title>
  <link rel="stylesheet" href="login_register.css">
 
</head>
<body>
  <div class="container">
    <div class="hello" id="login1">
      <h2>Forget Password</h2>
      <form method="POST" id="login">
        
        <input type="email" id="email" name="email" placeholder="Enter your email" required>
        <span class="field_error" id="email_error"></span><br>

        <button type="button" onclick="forgot_password()" id="btn_submit">Login</button>
        

        
     


      <div class="output">
        <p class="messege field_error "></p>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
		function forgot_password(){
			jQuery('#email_error').html('');
			var email=jQuery('#email').val();
			if(email==''){
				jQuery('#email_error').html('Please enter email id');
			}else{
				jQuery('#btn_submit').html('Please wait...');
				jQuery('#btn_submit').attr('disabled',true);
				jQuery.ajax({
					url:'fpsubmit.php',
					type:'post',
					data:'email='+email,
					success:function(result){
						jQuery('#email').val('');
						jQuery('#email_error').html(result);
						jQuery('#btn_submit').html('Submit');
						jQuery('#btn_submit').attr('disabled',false);
					}
				})
			}
		}
		</script>
</body>
 <?php require('footer.php'); ?>
</html>