<?php
require('top.php');
$cat_id = mysqli_real_escape_string($con, $_GET['id']);
$sub_categories = '';
if (isset($_GET['sub_categories'])) {
  $sub_categories = mysqli_real_escape_string($con, $_GET['sub_categories']);
}



if ($cat_id > 0) {
  $get_product = get_product($con, '', $cat_id, '', '', $sub_categories);
} else {
  ?>
  <script>
    window.location.href = 'index.php';
  </script>
  <?php
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="body.css">
  <style>
    .image-container {
      position: relative;
      display: inline-block;
    }

    .wishlist-icon {
      position: absolute;
      top: 10px;
      right: 10px;
      font-size: 24px;
      color: #ccc;
      opacity: 0;
      transition: opacity 0.3s ease;
      cursor: pointer;
    }

    .wishlist-icon.selected {
      color: red;
      opacity: 1;
    }

    .image-container:hover .wishlist-icon:not(.selected) {
      opacity: 1;
    }

    .disable-hover .wishlist-icon {
      opacity: 1;
    }

    .product-info {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      margin-top: 10px;
    }

    .product-info .price {
      position: relative;
      font-size: 16px;
      margin: 0;
    }

    .product-info .price::before {
      content: '';
      position: absolute;
      top: 50%;
      left: -10px;
      transform: translateY(-50%);
      width: 8px;
      height: 8px;
      background-color: #313131;
      border-radius: 50%;
    }

    .product-info .selling-price {
      font-weight: bold;
      color: #fff;
      margin: 0;
    }

    .info {
      list-style: none;
      padding: 0;
      margin: 5px 0 0 0;
    }

    .info li {
      margin-bottom: 5px;
    }

    h2 {
      color: #313131;
      font-family: Poppins;
      font-size: 40px;
      font-weight: 700;
      text-align: center;
      margin: 0;
      padding-top: 20px;
      padding-bottom: 0;
    }

    .product-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      margin-top: 0;
      padding-top: 40px;
      padding-bottom: 40px;
    }

    .product {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .product-image img {
      cursor: pointer;
      width: 256px;
      height: 346px;
    }

    .product-icons {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 10px;
    }

    .product-icons span {
      width: 30px;
      height: 30px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 20px;
      color: white;
      margin: 2px;
      background-color: rgba(0, 0, 0, 0.7);
    }

    .product:hover .product-info {
      display: block;
    }

    .product-info h5 {
      margin: 0;
    }

    .product-info .oldprice {
      text-decoration: line-through;
      color: #888;
    }

    .info li {
      display: inline-block;
      margin-right: 10px;
    }

    /* reponsive */
    /* Add media query for mobile devices */
    @media (max-width: 768px) {
      .product-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        padding-top: 50px;
        padding-bottom: 50px;
      }
    }

    /* Adjust product image size for smaller screens */
    @media (max-width: 480px) {
      .product-image img {
        width: 100%;
        height: auto;
      }
    }

    /* Make product info and prices stack vertically on small screens */
    @media (max-width: 480px) {
      .product-info {
        margin-top: 5px;
      }

      .product-info .price {
        font-size: 14px;
      }

      .product-info .price::before {
        display: none;
      }

      .product-info .selling-price {
        font-size: 16px;
      }

      .info li {
        display: block;
        margin-right: 0;
      }
    }
  </style>
  <title>Document</title>
</head>

<body>
  <section class="new-arrivals">

    <?php if (count($get_product) > 0) { ?>
      <div class="product-grid">
        <?php

        foreach ($get_product as $list) {
          ?>
          <div class="product">
            <div class="product-image">
              <div class="image-container">
                <img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $list['image'] ?>" alt="Product 1" class="a1">
                <a href="#"><i class="wishlist-icon far fa-heart"></i></a>

              </div>
              <div class="product-info">
                <h5><a href="product_details.php?id=<?php echo $list['id'] ?>"><?php echo $list['name'] ?></a></h5>
                <ul class="info">
                  <li class="oldprice">
                    <?php echo $list['mrp'] ?>
                  </li>
                  <li>
                    <?php echo $list['price'] ?>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>

    <?php } else {
      echo "data not found";
    } ?>
  </section>
  <script>
  </script>
</body>

</html>

<?php
require('footer.php'); ?>

</html>