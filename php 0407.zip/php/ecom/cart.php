<?php
require('top.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
      *{
  box-sizing: border-box;
} 
body {
    margin: 0;
    padding: 0;
    overflow-x: hidden; /* Prevent horizontal scroll */
  }
  
  .shopping-cart {
    width: 90%; /* Adjust the width as needed */
    max-width: 1200px; /* Adjust the maximum width as needed */
    margin: 20px auto; /* Center the cart on the page */
    padding: 20px;
    box-sizing: border-box;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 40px;
  }
  
  th, td {
    text-align: left;
    padding: 10px;
    border-bottom: 1px solid #ddd;
  }
  
  th {
    background-color: #f2f2f2;
  }
  
  .remove-icon {
    cursor: pointer;
  }
  
  .cart-buttons {
    display: flex;
    justify-content: space-between;
    margin-top: 75px;
    margin-bottom: 114px;
  }
  
  .continue-shopping,
  .update,
  .checkout {
    padding: 10px 20px;
    font-size: 14px;
    background-color: #4CAF50;
    color: white;
    border: none;
    cursor: pointer;
  }
  
  .update,
  .checkout {
    background-color: #f44336;
    margin-left: 10px;
  }
  
  .quantity {
    display: flex;
    align-items: center;
  }
  
  .decrement,
  .increment {
    display: inline-block;
    width: 20px;
    height: 20px;
    background-color: #f2f2f2;
    text-align: center;
    cursor: pointer;
  }
  
  .decrement:hover,
  .increment:hover {
    background-color: #e0e0e0;
  }
  
  input[type="number"] {
    width: 40px;
    padding: 5px;
    text-align: center;
    border: none;
    border-radius: 4px;
  }
.op img{
    height: 122px;
    width: 92px;
}  

.tr th,td {
text-align: center;
}
.quantity {
    display: flex;
    align-items: center;
    justify-content: center; /* Add this line to center the content horizontally */
  }
  
  .decrement,
  .increment {
    display: inline-block;
    width: 20px;
    height: 20px;
    background-color: #f2f2f2;
    text-align: center;
    cursor: pointer;
  }
  .continue{
    text-decoration: none;
    color: white;
  }




  @media (max-width: 768px) {
  .shopping-cart {
    width: 100%;
    padding: 10px;
    overflow-x: auto; /* Add this line to enable horizontal scroll */
  }

  table {
    margin-top: 20px;
    width: 100%; /* Add this line to ensure the table takes up the full width */
    font-size: 8px;
   
  }

  .tr th,
  .tr td {
    text-align: center;
    padding: 4px;
  }

  .op img {
    height: 60px;
    width: 40px;
  }

  .cart-buttons {
    flex-direction: row;
    margin-top: 40px;
    margin-bottom: 40px;
    width: 80%;
    margin-left: 33px;
  }

  .continue-shopping,
  .update,
  .checkout {
    width: 100%;
    margin-bottom: 10px;
  }
  
  .quantity {
    flex-direction: column;
    align-items: flex-start;
    margin-top: 10px;
  }

  .quantity input[type="number"] {
    width: 40px;
    font-size: 10px;
    
  }
 .rb{
  width: 50px;
  font-size: 8px;
 
}

}


  

  
    </style>
    <title>Document</title>
</head>
<body>
<div class="shopping-cart">
  <table>
    <thead>
      <tr class="tr">
        <th>PRODUCTS IMAGE</th>
        <th>NAME OF PRODUCTS</th>
        <th>MRP</th>
        <th>PRICE</th>
        <th>QUANTITY</th>
        <th>TOTAL</th>
        <th>REMOVE</th>
      </tr>
    </thead>
    <tbody>
    <?php
										if(isset($_SESSION['cart'])){
											foreach($_SESSION['cart'] as $key=>$val){
											$productArr=get_product($con,'','',$key);
											$pname=$productArr[0]['name'];
											$mrp=$productArr[0]['mrp'];
											$price=$productArr[0]['price'];
											$image=$productArr[0]['image'];
											$qty=$val['qty'];
											?>
      <tr class="tr">
        <td class="op"><img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$image?>"  /></td>
        <td><?php echo $pname?></td>
        <td><?php echo $mrp?></td>
        <td><?php echo $price?></td>

        <td>
          <div class="quantity">
           
          <input type="number" id="<?php echo $key?>qty" value="<?php echo $qty?>" />
            <a href="javascript:void(0)" onclick="manage_cart('<?php echo $key?>','update')">update</a>
          
          </div>
        </td>
        <td><?php echo $qty*$price?></td>
        <td><button type="button" class="rb"><a href="javascript:void(0)" onclick="manage_cart('<?php echo $key?>','remove')" >REMOVE</a></button></td>
      </tr>
      <?php } }?>
    </tbody>
  </table>

  <div class="cart-buttons">
    <button class="continue-shopping"> <a href="<?php echo SITE_PATH?>" class="continue">Continue Shopping</a></button>
    <div class="update-checkout">
      <button class="checkout"><a href="<?php echo SITE_PATH?>checkout.php" class="continue">Checkout</a></button>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
  function manage_cart(pid,type){
	if(type=='update'){
		var qty=jQuery("#"+pid+"qty").val();
	}else{
		var qty=jQuery("#qty").val();
	}
	jQuery.ajax({
		url:'manage_cart.php',
		type:'post',
		data:'pid='+pid+'&qty='+qty+'&type='+type,
		success:function(result){
			if(type=='update' || type=='remove'){
				window.location.href='cart.php';
			}
			jQuery('.htc__qua').html(result);
		}	
	});	
}

</script>
    
</body>
<?php
require('footer.php');?>
</html>