<?php
require('top.php');
if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    ?>
    <script>
        window.location.href = 'index.php';
    </script>
    <?php
}
$cart_total = 0;
foreach ($_SESSION['cart'] as $key => $val) {
    $productArr = get_product($con, '', '', $key);
    $price = $productArr[0]['price'];
    $qty = $val['qty'];
    $cart_total = $cart_total + ($price * $qty);
}

if (isset($_POST['submit'])) {
    $address = get_safe_value($con, $_POST['address']);
    $city = get_safe_value($con, $_POST['city']);
    $pincode = get_safe_value($con, $_POST['pincode']);
    $payment_type = get_safe_value($con, $_POST['payment_type']);
    $user_id = $_SESSION['USER_ID'];
    $total_price = $cart_total;
    $order_status = '1';
    $added_on = date('Y-m-d h:i:s');

    mysqli_query($con, "insert into `order`(user_id,address,city,pincode,payment_type,order_status,added_on,total_price) values('$user_id','$address','$city','$pincode','$payment_type','$order_status','$added_on','$total_price')");

    $order_id = mysqli_insert_id($con);

    foreach ($_SESSION['cart'] as $key => $val) {
        $productArr = get_product($con, '', '', $key);
        $price = $productArr[0]['price'];
        $qty = $val['qty'];

        mysqli_query($con, "insert into `order_detail`(order_id,product_id,qty,price) values('$order_id','$key','$qty','$price')");
    }
    unset($_SESSION['cart'])
        ?>
    <script>
        window.location.href = 'thankyou.php';
    </script>
    <?php


} ?>
<!DOCTYPE html>
<html>

<head>
    <title>Divisions Example</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        .hidden {
            display: none;
        }

        .toggle-button::before {
            content: "+";
            font-weight: bold;
            margin-right: 5px;
        }

        .toggle-button.open::before {
            content: "-";
        }

        .container {
            display: flex;
        }

        .left-container {
            flex: 3.25;
            padding-right: 20px;
            padding-left: 50px;
            padding-top: 19.920px;
        }

        .left {
            background-color: lightblue;
            padding: 20px;
            margin-bottom: 20px;
        }

        .right-container {
            padding-top: 40px;
            padding-left: 50px;
            padding-right: 50px;
            padding-bottom: 40px;
            flex: 1.75;
            /* Adjust the flex value to change the width */
            display: flex;
            flex-direction: column;
        }

        .right {
            background-color: lightgreen;
            padding: 20px;
        }

        .sub-menu {
            max-height: 0;
            overflow: hidden;
            padding: 10px;
            margin-top: 10px;
            transition: max-height 0.3s ease-in-out;
        }

        .toggle-button {
            cursor: pointer;
        }

        /* Additional styling for toglee class */
        .toglee {
            background-color: #f4f4f4;
            padding: 30px 0px 30px 30px;
            color: #666666;
        }

        /* LOGIN AMND GEGISTER */
        .form-container {
            display: flex;
            justify-content: space-between;

            padding-right: 20px;

        }

        .login-form,
        .register-form {
            max-width: 45%;
            /* Adjust the width as needed */
        }

        /* Additional styling */
        .form-container h3 {
            text-align: center;
        }

        .form-container form {
            margin-top: 10px;
        }

        .form-container label {
            display: block;
            margin-bottom: 5px;
        }

        .form-container input[type="text"],
        .form-container input[type="password"] {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
        }

        .form-container button[type="button"] {
            width: 100%;
            padding: 10px;
            background-color: lightblue;
            border: none;
            color: white;
            cursor: pointer;
        }

        /* for small order cart */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 50px;
            max-height: 50px;
        }

        .remove-icon {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .remove-icon i {
            color: red;
            font-size: 18px;
            cursor: pointer;
        }

        /* Styles for the order summary */
        .order-summary {
            margin-top: 20px;
        }

        .order-summary table {
            width: 100%;
        }

        .order-summary td {
            padding: 5px 8px;
        }

        .hito {
            text-align: center;
            margin-bottom: 50px;
        }

        /* responsive */
        @media screen and (max-width: 768px) {

            /* CSS styles for screens up to 768px wide */
            .container {
                flex-direction: column-reverse;
            }

            .left-container,
            .right-container {
                flex: 1;
                padding: 20px;
            }

            .left-container {
                padding-right: 0;
                padding-bottom: 0;
            }

            .right-container {
                padding-top: 0;
                padding-left: 0;
                padding-right: 0;
                padding-bottom: 0;
            }

            .form-container {
                flex-direction: column;
            }

            .login-form,
            .register-form {
                max-width: 100%;
                margin-bottom: 20px;
            }

            .ct {
                margin-left: 31px;
            }

            .line-break::after {
                content: "\A";
                white-space: pre;
            }

        }

        @media screen and (max-width: 480px) {

            /* CSS styles for screens up to 480px wide */
            .left-container,
            .right-container {
                padding: 10px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="left-container">
            <?php
            if (!isset($_SESSION['USER_LOGIN'])) {
                ?>
                <h2 class="toglee">
                    <span id="toggle1" class="toggle-button" onclick="toggleDivision(1)"></span> Login and Register
                </h2>
                <div id="division1" class="hidden">
                    <div class="form-container">
                        <div class="login-form" id="login1">
                            <h3>Login</h3>
                            <form method="POST" id="login">
                                <input type="email" id="login_email" name="login_email" placeholder="Enter your email"
                                    required>
                                <span class="field_error" id="login_email_error"></span><br>
                                <input type="password" id="login_password" name="login_password"
                                    placeholder="Enter your password" required>
                                <span class="field_error" id="login_password_error"></span><br>
                                <button type="button" onclick="user_login()">Login</button>
                            </form>
                            <p class="messege field_error "></p>
                        </div>
                        <div class="register-form">
                            <h3>Register</h3>
                            <form method="POST" id="register">
                                <input type="text" id="name" name="name" placeholder="Enter your name" required>
                                <span class="field_error" id="name_error"></span><br>
                                <input type="email" id="email" name="email" placeholder="Enter your email" required>
                                <span class="field_error" id="email_error"></span><br>
                                <input type="tel" id="mobile" name="mobile" pattern="[1-9]{1}[0-9]{9}"
                                    placeholder="Enter your mobile" required>
                                <span class="field_error" id="mobile_error"></span><br>
                                <input type="password" id="password" name="password" placeholder="Enter your password"
                                    required>
                                <span class="field_error" id="password_error"></span><br>
                                <button type="button" onclick="user_register()">Register</button>
                            </form>
                        </div>
                    </div>
                </div>
                <h2 class="toglee">
                    <span id="toggle2"></span> Address Information
                </h2>
                <h2 class="toglee">
                    <span id="toggle3"></span> Left Division 3
                </h2>
            <?php } else { ?>
                <h2 class="toglee">
                    <span id="toggle1"></span> Login and Register
                </h2>
                <h2 class="toglee">
                    <span id="toggle2" class="toggle-button" onclick="toggleDivision(2)"></span> Address Information
                </h2>
                <div id="division2">
                    <h3>Add Address Information</h3>
                    <form method="post">
                        <label for="address">Address:</label>
                        <input type="text" id="address" name="address" required>
                        <span class="line-break"></span>

                        <label for="city">City:</label>
                        <input type="text" id="city" name="city" class="ct" required>
                        <span class="line-break"></span>

                        <label for="pincode">Pincode:</label>
                        <input type="text" id="pincode" name="pincode" required>

                </div>
                <h2 class="toglee">
                    <span id="toggle3" class="toggle-button" onclick="toggleDivision(3)"></span> Left Division 3
                </h2>
                <div id="division3" class="hidden">
                    COD <input type="radio" name="payment_type" value="COD" required />
                    &nbsp;&nbsp;Esewa <input type="radio" name="payment_type" value="payu" required disabled />
                </div>
                <button type="submit" class="hito" name="submit">Submit</button>
                </form>
            <?php } ?>
        </div>
        <div class="right-container">
            <div class="right">
                <div class="orderdetails">
                    <h2>Order Details</h2>
                    <table class="luffy">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $cart_total = 0;
                            foreach ($_SESSION['cart'] as $key => $val) {
                                $productArr = get_product($con, '', '', $key);
                                $pname = $productArr[0]['name'];
                                $mrp = $productArr[0]['mrp'];
                                $price = $productArr[0]['price'];
                                $image = $productArr[0]['image'];
                                $qty = $val['qty'];
                                $cart_total = $cart_total + ($price * $qty);
                                ?>
                                <tr>
                                    <td><img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $image ?>" /></td>
                                    <td>
                                        <?php echo $pname ?>
                                    </td>
                                    <td>
                                        <?php echo $price * $qty ?>
                                    </td>
                                    <td> <a href="javascript:void(0)"
                                            onclick="manage_cart('<?php echo $key ?>','remove')"><i
                                                class="fas fa-times"></i></td>
                                </tr>
                            </tbody>
                        <?php } ?>
                    </table>
                </div>
                <div class="order-summary">
                    <table>
                        <tr>
                            <td>Order Total</td>
                            <td>
                                <?php echo $cart_total ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script>
        function toggleDivision(divisionNumber) {
            var division = document.getElementById("division" + divisionNumber);
            var toggle = document.getElementById("toggle" + divisionNumber);
            var isOpen = !division.classList.contains("hidden");
            // Close all divisions
            var divisions = document.querySelectorAll(".left-container > div");
            for (var i = 0; i < divisions.length; i++) {
                divisions[i].classList.add("hidden");
            }
            // Remove "open" class from all toggle buttons
            var toggleButtons = document.getElementsByClassName("toggle-button");
            for (var i = 0; i < toggleButtons.length; i++) {
                toggleButtons[i].classList.remove("open");
            }
            // Open the clicked division if it was previously closed
            if (!isOpen) {
                division.classList.remove("hidden");
                toggle.classList.add("open");
            }
        }
        // FORM INVALID WORD JS
        function validateForm() {
            // var restrictedWords = ["Madhesh Pradesh", "restricted", "forbidden"]; // Restricted words
            var acceptedCityWords = ["BRT", "BIRATNAGAR", "biratnagar", "Biratnagar"]; // Accepted words for city
            var acceptedStateWords = ["Pradesh 1", "1", "Koshi Pradesh", "Koshi"]; // Accepted words for state
            var streetInput = document.getElementById("street").value;
            var cityInput = document.getElementById("city").value;
            var stateInput = document.getElementById("state").value;
            // if (containsRestrictedWord(streetInput, restrictedWords)) {
            //     alert("Invalid street input. Please avoid using restricted words.");
            //     return false;
            // }
            if (!containsAcceptedWord(cityInput, acceptedCityWords)) {
                alert("Currently we are operating in Biratnagar Only");
                return false;
            }

            if (!containsAcceptedWord(stateInput, acceptedStateWords)) {
                alert("Sorry we only operate in Koshi Pradesh");
                return false;
            }

            return true;
        }
        function containsRestrictedWord(input, restrictedWords) {
            for (var i = 0; i < restrictedWords.length; i++) {
                if (input.toLowerCase().includes(restrictedWords[i].toLowerCase())) {
                    return true;
                }
            }
            return false;
        }
        function containsAcceptedWord(input, acceptedWords) {
            for (var i = 0; i < acceptedWords.length; i++) {
                if (input.toLowerCase().includes(acceptedWords[i].toLowerCase())) {
                    return true;
                }
            }
            return false;
        }
        function manage_cart(pid, type) {
            if (type == 'update') {
                var qty = jQuery("#" + pid + "qty").val();
            } else {
                var qty = jQuery("#qty").val();
            }
            jQuery.ajax({
                url: 'manage_cart.php',
                type: 'post',
                data: 'pid=' + pid + '&qty=' + qty + '&type=' + type,
                success: function (result) {
                    if (type == 'update' || type == 'remove') {
                        window.location.href = 'checkout.php';
                    }
                    jQuery('.htc__qua').html(result);
                }
            });
        }
        // FOR RESGISTER
        function user_register() {
            jQuery('.field_error').html('');
            var name = jQuery("#name").val();
            var email = jQuery("#email").val();
            var mobile = jQuery("#mobile").val();
            var password = jQuery("#password").val();
            var is_error = '';

            if (name == "") {
                jQuery('#name_error').html('Please enter name');
                is_error = 'yes';
            }
            if (email == "") {
                jQuery('#email_error').html('Please enter email');
                is_error = 'yes';
            }
            if (mobile == "") {
                jQuery('#mobile_error').html('Please enter mobile');
                is_error = 'yes';
            } else {
                // Phone number pattern validation
                var phonePattern = /^\d{10}$/; // Assuming a 10-digit phone number is required
                if (!phonePattern.test(mobile)) {
                    jQuery('#mobile_error').html('Please enter a valid 10-digit phone number');
                    is_error = 'yes';
                }
            }
            if (password == "") {
                jQuery('#password_error').html('Please enter password');
                is_error = 'yes';
            }
            if (is_error == '') {
                jQuery.ajax({
                    url: 'register_submit.php',
                    type: 'post',
                    data: 'name=' + name + '&email=' + email + '&mobile=' + mobile + '&password=' + password,
                    success: function (result) {
                        if (result == 'email_present') {
                            jQuery('#email_error').html('Email id already present');
                        }
                        if (result == 'insert') {
                            jQuery('#register1 p').html('Thanks for registering');
                            window.location.href = window.location.href;

                        }
                    }
                });
            }
        }
        // FOR LOGIN
        function user_login() {
            jQuery('.field_error').html('');
            var email = jQuery("#login_email").val();
            var password = jQuery("#login_password").val();
            var is_error = '';
            if (email == "") {
                jQuery('#login_email_error').html('Please enter email');
                is_error = 'yes';
            }
            if (password == "") {
                jQuery('#login_password_error').html('Please enter password');
                is_error = 'yes';
            }
            if (is_error == '') {
                jQuery.ajax({
                    url: 'login_submit.php',
                    type: 'post',
                    data: 'email=' + email + '&password=' + password,
                    success: function (result) {
                        if (result == 'wrong') {
                            jQuery('#login1 p').html('Please enter valid login details');
                        }
                        if (result == 'valid') {
                            window.location.href = window.location.href;
                        }
                    }
                });
            }
        }
    </script>
</body>
<?php
require('footer.php'); ?>

</html>