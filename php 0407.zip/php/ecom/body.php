<?php
require('top.php'); ?>
<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <style>
    .product-info {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      margin-top: 10px;
    }

    .product-info .price {
      position: relative;
      font-size: 16px;
      margin: 0;
    }

    .product-info .price::before {
      content: '';
      position: absolute;
      top: 50%;
      left: -10px;
      transform: translateY(-50%);
      width: 8px;
      height: 8px;
      background-color: #313131;
      border-radius: 50%;
    }

    .product-info .selling-price {
      font-weight: bold;
      color: #fff;
      margin: 0;
    }

    .info {
      list-style: none;
      padding: 0;
      margin: 5px 0 0 0;
    }

    .info li {
      margin-bottom: 5px;
    }

    /* Additional Styles */
    h2 {
      color: #313131;
      font-family: Poppins;
      font-size: 40px;
      font-weight: 700;
      text-align: center;
      margin: 0;
      padding-top: 20px;
      padding-bottom: 0;
    }

    .abc {
      color: #313131;
      font-family: Poppins;
      font-size: 20px;
      font-weight: 450;
      text-align: center;
      margin-top: 23px;
      padding: 0;
    }

    .product-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      margin-top: 0;
      padding-top: 40px;
      padding-bottom: 40px;
    }

    .product {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .product-image img {

      cursor: pointer;
      width: 256px;
      height: 346px;

    }

    .product-icons {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 10px;
    }

    .product-icons span {
      width: 30px;
      height: 30px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 20px;
      color: white;
      margin: 2px;
      background-color: rgba(0, 0, 0, 0.7);
    }

    .product:hover .product-info {
      display: block;
    }

    .product-info h5 {
      margin: 0;
    }

    .product-info .oldprice {
      text-decoration: line-through;
      color: #888;
    }

    .info li {
      display: inline-block;
      margin-right: 10px;
    }






    .image-container {
      position: relative;
      display: inline-block;
    }

    .wishlist-icon {
      position: absolute;
      top: 10px;
      right: 10px;
      font-size: 24px;
      color: #ccc;
      opacity: 0;
      transition: opacity 0.3s ease;
      cursor: pointer;
    }

    .wishlist-icon.selected {
      color: red;
      opacity: 1;
    }

    .image-container:hover .wishlist-icon:not(.selected) {
      opacity: 1;
    }

    .disable-hover .wishlist-icon {
      opacity: 1;
    }

/* responsive ho hai */
@media (max-width: 768px) {
  h2 {
    font-size: 32px;
  }

  .abc {
    font-size: 16px;
    margin-top: 15px;
  }

  .product-grid {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-top: 0;
    padding-top: 20px;
    padding-bottom: 20px;
  }

  .product {
    width: calc(50% - 10px);
    margin-bottom: 20px;
  }

  .product-image img {
    width: 100%;
    height: auto;
  }
}

@media (max-width: 480px) {
  h2 {
    font-size: 28px;
  }

  .abc {
    font-size: 14px;
  }

  .product-grid {
    grid-template-columns: repeat(1, 1fr);
    gap: 10px;
    padding-top: 20px;
    padding-bottom: 20px;
  }
}




  </style>
</head>

<body>


  <main>
    <section class="new-arrivals">
      <h2>New Arrivals</h2>
      <p class="abc">Products we added to stock recently</p>

      <div class="product-grid">
        <?php
        $get_product = get_product($con, 4);
        foreach ($get_product as $list) {
          ?>
          <div class="product">
            <div class="product-image">
              <div class="image-container">
                <img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $list['image'] ?>" alt="Product 1" class="a1">
                <a href="javascript:void(0)" onclick="wishlist_manage('<?php echo $list['id'] ?>','add')"><i
                    class="wishlist-icon far fa-heart"></i></a>
              </div>

              <div class="product-info">
                <h5><a href="product_details.php?id=<?php echo $list['id'] ?>"><?php echo $list['name'] ?></a></h5>
                <ul class="info">
                  <li class="oldprice">
                    <?php echo $list['mrp'] ?>
                  </li>
                  <li>
                    <?php echo $list['price'] ?>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </section>
  </main>
  <main>
    <section class="new-arrivals">
      <h2>Best Seller</h2>
      <p class="abc">Product we added in stock recently</p>
      <div class="product-grid">
        <?php
        $get_product = get_product($con, 4, '', '', 'yes');
        foreach ($get_product as $list) {
          ?>
          <div class="product">
            <div class="product-image">
              <div class="image-container">
                <img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $list['image'] ?>" alt="Product 1" class="a1">
                <a href="javascript:void(0)" onclick="wishlist_manage('<?php echo $list['id'] ?>','add')"><i
                    class="wishlist-icon far fa-heart"></i></a>
              </div>
              <div class="product-info">
                <h5><a href="product_details.php?id=<?php echo $list['id'] ?>"><?php echo $list['name'] ?></a></h5>
                <ul class="info">
                  <li class="oldprice">
                    <?php echo $list['mrp'] ?>
                  </li>
                  <li>
                    <?php echo $list['price'] ?>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
      </div>

      </div>
    </section>
  </main>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script>
    function wishlist_manage(pid, type) {
      jQuery.ajax({
        url: 'wishlist_manage.php',
        type: 'post',
        data: 'pid=' + pid + '&type=' + type,
        success: function (result) {
          if (result == 'not_login') {
            window.location.href = 'login_register.php';
          } else {
            jQuery('.hello').html(result);
          }
        }
      });
    }
  </script>
</body>
<?php
require('footer.php'); ?>

</html>