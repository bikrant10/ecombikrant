<?php
require('connection1.inc.php');
require('function1.inc.php');
require('add_to_cart.inc.php');
$cat_res = mysqli_query($con, "select * from categories where status=1 order by categories asc");
$cat_arr = array();
while ($row = mysqli_fetch_assoc($cat_res)) {
  $cat_arr[] = $row;
}
$obj = new add_to_cart();
$totalProduct = $obj->totalProduct();


if (isset($_SESSION['USER_LOGIN'])) {
  $uid = $_SESSION['USER_ID'];

  if (isset($_GET['wishlist_id'])) {
    $wid = get_safe_value($con, $_GET['wishlist_id']);
    mysqli_query($con, "delete from wishlist where id='$wid' and user_id='$uid'");
  }

  $wishlist_count = mysqli_num_rows(mysqli_query($con, "select product.name,product.image,product.price,product.mrp,wishlist.id from product,wishlist where wishlist.product_id=product.id and wishlist.user_id='$uid'"));
}

$script_name = $_SERVER['SCRIPT_NAME'];
$script_name_arr = explode('/', $script_name);
$mypage = $script_name_arr[count($script_name_arr) - 1];



$meta_title = "My Ecom Website";
$meta_desc = "My Ecom Website";
$meta_keyword = "My Ecom Website";
if ($mypage == 'product_details.php') {
  $product_id = get_safe_value($con, $_GET['id']);
  $product_meta = mysqli_fetch_assoc(mysqli_query($con, "select * from product where id='$product_id'"));
  $meta_title = $product_meta['meta_title'];
  $meta_desc = $product_meta['meta_desc'];
  $meta_keyword = $product_meta['meta_keyword'];
}
if ($mypage == 'contact.php') {
  $meta_title = 'Contact Us';
}
?>
<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>
    <?php echo $meta_title ?>
  </title>
  <meta name="description" content="<?php echo $meta_desc ?>">
  <meta name="keywords" content="<?php echo $meta_keyword ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #f7d2d2;
    }

    header {
      background-color: #f2f2f2;
      margin-bottom: 20px;
      height: 45px;
      margin-left: 5px;
      margin-right: 5px;
    }

    .navbar {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: transparent;
      padding: 10px;
      transition: background-color 0.3s ease-in-out, top 0.3s ease-in-out;
      z-index: 1000;
    }

    .navbar.scrolled {
      background-color: #f2f2f2;
    }

    .navbar-logo {
      font-weight: bold;
      font-size: 20px;
    }

    .navbar-menu {
      list-style: none;
      display: flex;
      align-items: center;
      margin: 0;
    }

    .navbar-menu li {
      margin-right: 15px;
      cursor: pointer;
    }

    .navbar-icons {
      display: flex;
      align-items: center;
      
    }

    .navbar-icons i {
      margin: 0 5px;
      cursor: pointer;
    }
    .navbar-icons a {
      margin-right: 5px;
    }
    .content {
      padding: 20px;
      padding-top: 0px;
    }
    
    .cart-menu {
      opacity: 1;
      padding-bottom: 50px;
      right: calc(0px - 16px);
      background: #eeeeee none repeat scroll 0 0;
      box-shadow: 0 0 85px rgba(0, 0, 0, 0.2);
      display: block;
      height: 100vh;
      overflow-y: scroll;
      position: fixed;
      top: 0;
      transition: all 0.25s ease 0s;
      z-index: 99999;
      width: 475px;
    }

    .cart-menu.hidden {
      display: none;
    }

    .cart-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0px;
    }

    .cart-items {
      max-height: 300px;
      overflow-y: auto;
      height: 130px;
      width: 370px;
      padding-left: 100px;
    }

    .close-icon {
      margin-left: auto;
      cursor: pointer;
      padding-top: 25px;
      padding-bottom: 25px;
    }

    .cart-item {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
    }

    .cart-item img {
      width: 50px;
      height: 50px;
      margin-right: 10px;
    }

    .item-details h4,
    .item-details p {
      margin: 0;
    }

    .remove-icon {
      margin-left: auto;
      cursor: pointer;
    }

    .subtotal {
      font-weight: bold;
    }

    .view-cart-btn,
    .checkout-btn {
      margin-top: 5px;
    }

    table {
      border-collapse: collapse;
      width: 100%;
    }

    td,
    th {
      border: 1px solid #ddd;
      padding: 8px;
    }

    img {
      width: 50px;
      height: 50px;
    }









    /* Style for the dropdown container */
    .dropdown {
      position: relative;
      display: inline-block;
    }

    /* Style for the dropdown button/link */
    .dropbtn {
      display: inline-block;
      text-decoration: none;
      color: black;
      position: relative;
      z-index: 1;
    }

    /* Style for the dropdown content */
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
      z-index: 2;
      opacity: 0;
      transform: translateY(-10px);
      transition: opacity 0.3s ease, transform 0.3s ease;
      pointer-events: none;
    }

    /* Style for the dropdown links */
    .dropdown-content a {
      display: block;
      padding: 12px 16px;
      text-decoration: none;
      color: black;
      text-align: center;
      transition: background-color 0.3s ease;
    }

    /* Style for the dropdown links on hover */
    .dropdown-content a:hover {
      background-color: #f1f1f1;
    }


    .dropdown:hover .dropdown-content {
      display: block;
      opacity: 1;
      transform: translateY(0);
      pointer-events: auto;
    }


    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .dropdown-content {
      animation: slideIn 0.3s ease forwards;
    }

    .hiii{
      left: 115px;
    }



    @media screen and (max-width: 768px) {
      header {
        margin-bottom: 10px;
        height: 100%;
        width: 100%;
      }

      .navbar {
        flex-wrap: wrap;
        justify-content: center;
        padding: 0px;
        position: relative;
      }


      .navbar-menu {
        width: 100%;
        margin-top: 10px;
        text-align: center;
        padding: 10px;
        margin-top: 3px;
        flex-wrap: wrap;
        margin-left: 50px;
      }

      .navbar-menu li {
        display: block;
        /* margin: 10px 0; */

      }

      .cart-items {
        max-height: none;
        padding-left: 0;
      }

      .content {
        padding: 10px;
      }

      .navbar-logo {
        margin-top: 10px;
      }

      a.dropbtn {
        margin-right: 5px;
        margin-left: 5px;
      }

      ul.navbar-menu {
        padding: 0px;
        margin: 0px;
        margin-left: 20px;
      }
    }

    /* Media queries for screens up to 480px width */
    @media screen and (max-width: 480px) {
      header {
        margin-bottom: 10px;

      }

      .navbar-logo {
        font-size: 16px;
      }

      .navbar-menu li {
        margin-right: 8px;

      }

      .cart-items {
        max-height: none;
      }

      .content {
        padding: 5px;
      }
    }



    

    .navbar-logo {
      color: #fff;
      font-size: 24px;
      font-weight: bold;
      text-align: center;
      animation: glowing 2s ease-in-out infinite;


    }

    @keyframes glowing {
      0% {
        text-shadow: 0 0 10px #ff0000;
      }

      20% {
        text-shadow: 0 0 20px #ff4000;
      }

      40% {
        text-shadow: 0 0 30px #ff8000;
      }

      60% {
        text-shadow: 0 0 40px #ffff00;
      }

      80% {
        text-shadow: 0 0 50px #00ff00;
      }

      100% {
        text-shadow: 0 0 60px #0000ff;
      }
    
    }
    
  </style>
</head>

<body>
  <header>
    <nav class="navbar">
      <div class="navbar-logo">
        GADGET GHAR
      </div>

      <ul class="navbar-menu">
        <a href="body.php">
          <li class="drop">Home</li>
        </a>
        <?php
        foreach ($cat_arr as $list) {
          ?>
          <li class="dropdown">

            <a href="frontcategories.php?id=<?php echo $list['id'] ?>" class="dropbtn"><?php echo $list['categories'] ?></a>

            <?php
            $cat_id = $list['id'];

            $sub_cat_res = mysqli_query($con, "select * from sub_categories where status='1' and categories_id='$cat_id'");
            if (mysqli_num_rows($sub_cat_res) > 0) {
              ?>

              <div class="dropdown-content">
                <!-- Dropdown items go here -->

                <?php
                while ($sub_cat_rows = mysqli_fetch_assoc($sub_cat_res)) {
                  echo '<a href="frontcategories.php?id=' . $list['id'] . '&sub_categories=' . $sub_cat_rows['id'] . '">' . $sub_cat_rows['sub_categories'] . '</a>';
                } ?>
              </div>
            <?php } ?>
          </li>


          <?php
        }


        ?>

        <a href="contactfrontend.php">
          <li>CONTACT</li>
        </a>
      </ul>
      <?php if (isset($_SESSION['USER_LOGIN'])) {
        ?>




       
          <div class="dropdown hiii">
            <button class="dropbtn">Hi &nbsp; <?php echo $_SESSION['USER_NAME']?></button>
            <div class="dropdown-content">
              <a href="myorder.php">Order</a>
              <a href="profile.php">Profile</a>
              <a href="logoutu.php">Logout</a>
            </div>
           
            <?php 
      } else {
        echo '<a href="login_register.php" style="position: relative; left: 120px;">Login/Register</a>';
      }
      ?>
     
          </div>
         

  

      <?php
      if (isset($_SESSION['USER_ID'])) {
        ?>

        <div class="navbar-icons">
          <a href="wishlist.php" class="cart-icon">
            <i class="far fa-heart" style="width: 10px;">&#xf07a;</i>
            <span class="hello">
              <?php echo $wishlist_count ?>
            </span>

          </a>&nbsp;|&nbsp;

        <?php } ?>


        <div class="navbar-icons">
          <a href="cart.php" class="cart-icon">
            <i class="fa" style="width: 10px;">&#xf07a;</i>
            <span class='badge badge-warning' id='lblCartCount'>
              <?php echo $totalProduct ?>
            </span>
          </a>&nbsp;|&nbsp;








        </div>
    </nav>
  </header>



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script>
    // document.addEventListener("click", function (event) {
    //   var dropdowns = document.getElementsByClassName("dropdown-content");
    //   var i;
    //   for (i = 0; i < dropdowns.length; i++) {
    //     var openDropdown = dropdowns[i];
    //     if (openDropdown.classList.contains('show') && !openDropdown.contains(event.target)) {
    //       openDropdown.classList.remove('show');
    //     }
    //   }
    // });

    // document.getElementsByClassName("dropbtn")[0].addEventListener("click", function () {
    //   this.nextElementSibling.classList.toggle("show");
    // });

  </script>
</body>

</html>