-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2023 at 08:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'bikrant', 'bikrant123');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categories`, `status`) VALUES
(81, 'TV', 1),
(82, 'FRIDGE', 1),
(83, 'LAPTOP', 1),
(84, 'MOBILE', 1),
(85, 'AC', 1),
(86, 'DESKTOP', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(75) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `comment` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `mobile`, `comment`, `status`, `added_on`) VALUES
(23, 'Bikrant Basnet', 'bikrantbasnet69@gmail.com', '9810595498', 'Bye bro', 1, '2023-07-02 04:29:41');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `pincode` int(20) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `total_price` float NOT NULL,
  `order_status` varchar(50) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `user_id`, `address`, `city`, `pincode`, `payment_type`, `total_price`, `order_status`, `added_on`) VALUES
(20, 20, 'Biratnagar', 'Neoal', 28282, 'COD', 1234, '1', '2023-07-04 12:36:28');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` float NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `order_id`, `product_id`, `qty`, `price`, `added_on`) VALUES
(7, 7, 35, 1, 99999, '0000-00-00 00:00:00'),
(8, 8, 41, 1, 20, '0000-00-00 00:00:00'),
(9, 9, 40, 1, 12121, '0000-00-00 00:00:00'),
(10, 10, 41, 1, 20, '0000-00-00 00:00:00'),
(11, 10, 40, 1, 12121, '0000-00-00 00:00:00'),
(12, 10, 38, 2, 51000, '0000-00-00 00:00:00'),
(13, 10, 36, 1, 122000, '0000-00-00 00:00:00'),
(14, 10, 27, 1, 51000, '0000-00-00 00:00:00'),
(15, 11, 39, 1, 249999, '0000-00-00 00:00:00'),
(16, 12, 35, 1, 99999, '0000-00-00 00:00:00'),
(17, 12, 37, 1, 85000, '0000-00-00 00:00:00'),
(18, 12, 39, 1, 249999, '0000-00-00 00:00:00'),
(19, 12, 41, 1, 20, '0000-00-00 00:00:00'),
(20, 13, 40, 1, 12121, '0000-00-00 00:00:00'),
(21, 13, 35, 1, 99999, '0000-00-00 00:00:00'),
(22, 13, 27, 1, 51000, '0000-00-00 00:00:00'),
(23, 13, 37, 1, 85000, '0000-00-00 00:00:00'),
(24, 13, 36, 1, 122000, '0000-00-00 00:00:00'),
(25, 13, 39, 1, 249999, '0000-00-00 00:00:00'),
(26, 13, 38, 1, 51000, '0000-00-00 00:00:00'),
(27, 13, 41, 1, 20, '0000-00-00 00:00:00'),
(28, 13, 34, 1, 51000, '0000-00-00 00:00:00'),
(29, 14, 41, 9999999, 20, '0000-00-00 00:00:00'),
(30, 15, 40, 1, 12121, '0000-00-00 00:00:00'),
(31, 16, 40, 1, 12121, '0000-00-00 00:00:00'),
(32, 17, 39, 5, 249999, '0000-00-00 00:00:00'),
(33, 18, 41, 1, 20, '0000-00-00 00:00:00'),
(34, 19, 42, 1, 1234, '0000-00-00 00:00:00'),
(35, 20, 42, 1, 1234, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_status`
--

INSERT INTO `order_status` (`id`, `name`) VALUES
(1, 'Pending'),
(2, 'Processing'),
(3, 'Shipped'),
(4, 'Canceled'),
(5, 'Complete');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `sub_categories_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mrp` float NOT NULL,
  `price` float NOT NULL,
  `qty` int(11) NOT NULL,
  `image` text NOT NULL,
  `short_desc` text NOT NULL,
  `description` text NOT NULL,
  `best_seller` int(11) NOT NULL,
  `meta_title` varchar(2000) NOT NULL,
  `meta_desc` varchar(2000) NOT NULL,
  `meta_keyword` varchar(2000) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `categories_id`, `sub_categories_id`, `name`, `mrp`, `price`, `qty`, `image`, `short_desc`, `description`, `best_seller`, `meta_title`, `meta_desc`, `meta_keyword`, `status`) VALUES
(42, 82, 37, 'Samsung Fridge', 10000, 1234, 4, '101938197_dfridge.jpg', 'SAMSUNG 236 L Frost Free Double Door 2 Star Refrigerator with Digital Inverter  (BLACK, RT28C3032GS/HL)', 'The refrigerator comes in a box and includes a user manual and warranty card. It is a double door refrigerator with a top freezer. The defrosting type is frost-free, and it features a digital inverter compressor. With a capacity of 236 L, it has two doors and a 2-star rating. The refrigerator is equipped with toughened glass shelves and has a built-in stabilizer.\r\n\r\nIn terms of performance features, it offers temperature control but is not convertible. The shelf material is toughened glass, and it includes convenient features like a deodorizer and flexible rack.\r\n\r\nPower requirements for the refrigerator are AC 220 - 240 V, 50 Hz. It has a BEE rating year of 2023 and does not require an additional stabilizer.\r\n\r\nThe refrigerator compartment features an interior light and an egg tray. In the freezer compartment, it has a tray ice maker.\r\n\r\nThe dimensions of the refrigerator are as follows: net height of 1545 mm, net depth of 637 mm, and net width of 555 mm. The weight of the refrigerator is 46 kg.\r\n\r\nFor installation and demonstration, an authorized service engineer will assist with setting up the refrigerator and explain its usage, features, and do\'s and don\'ts.\r\n\r\nThe warranty for this refrigerator includes 1 year comprehensive coverage on the product and 20 years on the compressor. It covers all parts excluding plastic parts, glassware, bulb, and tube from the date of purchase against defective material and workmanship. However, it does not cover parts such as plastic, glassware, bulb, and tube. The warranty does not apply if the product is not used according to the instructions, if there are modifications made to the electrical circuitry or physical construction, or if the serial number is altered or removed. Additionally, defects caused by external factors like lightning, abnormal voltage, or acts of nature are not covered.', 1, 'SAMSUNG 236 L Frost Free Double Door 2 Star Refrigerator with Digital Inverter  (BLACK, RT28C3032GS/HL)', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `sub_categories` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `categories_id`, `sub_categories`, `status`) VALUES
(34, 81, 'LED', 1),
(35, 81, 'LCD', 1),
(36, 81, 'CRT', 1),
(37, 82, 'Double Door', 1),
(38, 82, 'Single Door', 1),
(39, 83, '14 INCH', 1),
(40, 83, '15.6 INCH', 1),
(41, 84, 'Android', 1),
(42, 84, 'IOS', 1),
(44, 85, '1 TON', 1),
(45, 85, '1.5 TON', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(125) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `email`, `mobile`, `added_on`) VALUES
(17, 'Aman', 'abc', 'amankarki@gmail.com', '9874563210', '2023-06-30 04:13:26'),
(20, 'Bikrant Basnet', 'bikrant123', 'bikrantbasnet69@gmail.com', '9810595498', '2023-07-02 06:02:16'),
(21, 'Sonal', 'sonal', 'sonalbasnet75@gmail.com', '9810595498', '2023-07-03 07:28:24');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`, `added_on`) VALUES
(5, 18, 41, '2023-07-02 06:37:31'),
(6, 18, 40, '2023-07-02 06:37:33'),
(7, 18, 39, '2023-07-02 06:37:34'),
(8, 18, 38, '2023-07-02 06:37:35'),
(19, 21, 40, '2023-07-03 07:35:45'),
(21, 20, 41, '2023-07-03 08:10:18'),
(22, 20, 40, '2023-07-03 08:10:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_status`
--
ALTER TABLE `order_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `order_status`
--
ALTER TABLE `order_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
