<?php
require('top.php');
$product_id = mysqli_real_escape_string($con, $_GET['id']);
$get_product = get_product($con, '', '', $product_id);

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    .main_part {
      display: flex;
    }

    .image_container {
      flex: 1;
      max-width: 40%;
      margin-right: 10px;
    }

    .img11 {
      cursor: pointer;
      width: 256px;
      height: 346px;
      margin-left: 285px;
    }

    .product_details {
      flex: 1;
    }

    .pricep {
      display: flex;
      align-items: baseline;
    }

    .mrpp {
      text-decoration: line-through;
      margin-right: 10px;
    }


    /* FOR DETAILS BOX HAI */
    .d-container {
      text-align: center;
      position: relative;
    }

    .d {
      display: inline-block;
      padding: 5px;
      border: 1px solid black;
      text-align: center;
      margin: 0 auto;
      cursor: pointer;
    }

    .more-details {
      display: none;
      padding: 10px;



    }

    .show {
      display: block;
    }

    .close-icon {
      float: right;
      font-weight: bold;
      cursor: pointer;
    }

    .label {
      display: inline-block;
      margin-right: 5px;
    }

    .category {
      display: inline-block;
    }

    button[type="button"] {
      background-color: #4CAF50;
      color: #fff;

      padding-left: 10px;
      padding-right: 10px;
      padding-top: 10px;
      padding-bottom: 10px;

      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 10px;
      transition: background-color 0.3s ease;
    }

    button[type="button"]:hover {
      background-color: #45a049;
    }


    /* responsive */

    @media only screen and (max-width: 600px) {
      .main_part {
   flex-direction: row;
      }

      .img11 {
        
        margin-left: 35px;
        margin-right: 100px;
        margin-top: 30px;
        width: 100%;
        height: 90%;
      }
     

      .product_details {
        margin-left: 60px;
      }
      .d-container{
        margin-top: 15px;
        margin-bottom: 15px;
      }
    }

 

  </style>
  <title>Document</title>
</head>

<body>
  <?php if (count($get_product) > 0) { ?>
    <div class="main_part">
      <div class="image_container">
        <img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $get_product['0']['image'] ?>" class="img11">
      </div>
      <div class="product_details">
        <h3 class="namep">
          <?php echo $get_product['0']['name'] ?>
        </h3>
        <div class="pricep">
          <span class="mrpp">
            <?php echo $get_product['0']['mrp'] ?>
          </span>
          <span class="price1">
            <?php echo $get_product['0']['price'] ?>
          </span>
        </div>
        <p class="pro_details_ho">
          <?php echo $get_product['0']['short_desc'] ?>
        </p>
        <p>Availability: In stock</p>
        <div class="qty">
          <p>
            <span>Quantity</span>
            <select id="qty">
              <script>
                for (var i = 1; i <= 100; i++) {
                  document.write('<option>' + i + '</option>');
                }
              </script>
            </select>

          </p>
        </div>

        <span class="label">Categories:</span>
        <p class="category"><a href="#">
            <?php echo $get_product['0']['categories'] ?>
          </a></p><br>
        <button type="button"><a href="javascript:void(0)"
            onclick="manage_cart('<?php echo $get_product['0']['id'] ?> ','add')">ADD TO CART</a> </button>
      </div>
    </div>
    <div class="d-container">
      <p class="d">More Details</p>
      <div class="more-details">
        <p>
          <?php echo $get_product['0']['description'] ?>
        </p>
      </div>
    </div>
    </div>
  <?php } else {
    echo "data not found";
  } ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script>
    const detailsBox = document.querySelector('.d');
    const moreDetails = document.querySelector('.more-details');

    detailsBox.addEventListener('click', () => {
      moreDetails.classList.toggle('show');
      detailsBox.textContent = detailsBox.textContent === 'CLOSE' ? 'More Details' : 'CLOSE';
    });
    function manage_cart(pid, type) {
      var qty = jQuery("#qty").val();
      jQuery.ajax({
        url: 'manage_cart.php',
        type: 'post',
        data: 'pid=' + pid + '&qty=' + qty + '&type=' + type,
        success: function (result) {
          jQuery('.badge ').html(result);
        }
      });
    }


  </script>
</body>
<?php
require('footer.php'); ?>

</html>