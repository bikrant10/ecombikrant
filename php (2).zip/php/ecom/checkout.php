<?php
require('top.php');
if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    ?>
    <script>
        window.location.href = 'index.php';
    </script>
    <?php
}
$cart_total = 0;
foreach ($_SESSION['cart'] as $key => $val) {
    $productArr=get_product($con,'','',$key);
    $price = $productArr[0]['price'];
    $qty = $val['qty'];
    $cart_total = $cart_total + ($price * $qty);
}

if (isset($_POST['submit'])) {
    $address = get_safe_value($con, $_POST['address']);
    $city = get_safe_value($con, $_POST['city']);
    $pincode = get_safe_value($con, $_POST['pincode']);
    $payment_type = get_safe_value($con, $_POST['payment_type']);
    $user_id = $_SESSION['USER_ID'];
    $total_price = $cart_total;
    $order_status = 'pending';
    $added_on = date('Y-m-d h:i:s');


    mysqli_query($con, "insert into `order`(user_id,address,city,pincode,payment_type,order_status,added_on,total_price) values('$user_id','$address','$city','$pincode','$payment_type','$order_status','$added_on','$total_price')");

    $order_id=mysqli_insert_id($con);
    
	foreach($_SESSION['cart'] as $key=>$val){
		$productArr=get_product($con,'','',$key);
		$price=$productArr[0]['price'];
		$qty=$val['qty'];
		
		mysqli_query($con,"insert into `order_detail`(order_id,product_id,qty,price) values('$order_id','$key','$qty','$price')");
	}
    unset($_SESSION['cart'])
	?>
	<script>
		window.location.href='thankyou.php';
	</script>
	<?php
	
	
}






?>
<!DOCTYPE html>
<html>

<head>
    <title>Divisions Example</title>
    <link rel="stylesheet" href="checkout.css">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />


</head>

<body>
    <div class="container">
        <div class="left-container">

            <?php
            // $a1 = 'toggle_button';
            if (!isset($_SESSION['USER_LOGIN'])) {
                // $a1 = 'toggle_button';
                ?>
                <h2 class="toglee">
                    <span id="toggle1" class="toggle-button" onclick="toggleDivision(1)"></span> Login and Register
                </h2>
                <div id="division1" class="hidden">
                    <div class="form-container">
                        <div class="login-form" id="login1">
                            <h3>Login</h3>
                            <form method="POST" id="login">

                                <input type="email" id="login_email" name="login_email" placeholder="Enter your email"
                                    required>
                                <span class="field_error" id="login_email_error"></span><br>


                                <input type="password" id="login_password" name="login_password"
                                    placeholder="Enter your password" required>
                                <span class="field_error" id="login_password_error"></span><br>

                                <button type="button" onclick="user_login()">Login</button>



                            </form>
                            <p class="messege field_error "></p>
                        </div>

                        <div class="register-form">
                            <h3>Register</h3>
                            <form method="POST" id="register">
                                <input type="text" id="name" name="name" placeholder="Enter your name" required>
                                <span class="field_error" id="name_error"></span><br>


                                <input type="email" id="email" name="email" placeholder="Enter your email" required>
                                <span class="field_error" id="email_error"></span><br>


                                <input type="tel" id="mobile" name="mobile" pattern="[1-9]{1}[0-9]{9}"
                                    placeholder="Enter your mobile" required>
                                <span class="field_error" id="mobile_error"></span><br>


                                <input type="password" id="password" name="password" placeholder="Enter your password"
                                    required>
                                <span class="field_error" id="password_error"></span><br>

                                <button type="button" onclick="user_register()">Register</button>
                            </form>
                        </div>
                    </div>
                </div>
                <h2 class="toglee">
                    <span id="toggle2"></span> Address Information
                </h2>
                <h2 class="toglee">
                    <span id="toggle3"></span> Left Division 3
                </h2>

            <?php } else { ?>
                <h2 class="toglee">
                    <span id="toggle1"></span> Login and Register
                </h2>
                <h2 class="toglee">
                    <span id="toggle2" class="toggle-button" onclick="toggleDivision(2)"></span> Address Information
                </h2>

                <div id="division2">
                    <h3>Add Address Information</h3>
                    <!-- <form onsubmit="return validateForm()" method="post"> -->
                    
                    <form  method="post">
                        <label for="address">Address:</label>
                        <input type="text" id="address" name="address">

                        <label for="city">City:</label>
                        <input type="text" id="city" name="city">

                        <label for="pincode">Pincode:</label>
                        <input type="text" id="pincode" name="pincode">



                </div>





                <h2 class="toglee">
                    <span id="toggle3" class="toggle-button" onclick="toggleDivision(3)"></span> Left Division 3
                </h2>
                <div id="division3" class="hidden">
                    COD <input type="radio" name="payment_type" value="COD" required />
                    &nbsp;&nbsp;Esewa <input type="radio" name="payment_type" value="payu" required disabled />

                </div>


                <button type="submit" class="hito" name="submit">Submit</button>


                </form>
            <?php } ?>
        </div>

        <div class="right-container">
            <div class="right">
                <div class="orderdetails">
                    <h2>Order Details</h2>

                    <table class="luffy">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $cart_total = 0;
                            foreach ($_SESSION['cart'] as $key => $val) {
                                $productArr = get_product($con, '', '', $key);
                                $pname = $productArr[0]['name'];
                                $mrp = $productArr[0]['mrp'];
                                $price = $productArr[0]['price'];
                                $image = $productArr[0]['image'];
                                $qty = $val['qty'];
                                $cart_total = $cart_total + ($price * $qty);
                                ?>
                                <tr>

                                    <td><img src="<?php echo PRODUCT_IMAGE_SITE_PATH . $image ?>" /></td>
                                    <td>
                                        <?php echo $pname ?>
                                    </td>
                                    <td>
                                        <?php echo $price * $qty ?>
                                    </td>
                                    <td> <a href="javascript:void(0)"
                                            onclick="manage_cart('<?php echo $key ?>','remove')"><i
                                                class="fas fa-times"></i></td>
                                </tr>
                            </tbody>

                        <?php } ?>
                    </table>

                </div>

                <div class="order-summary">
                    <table>
                        <tr>
                            <td>Order Total</td>
                            <td>
                                <?php echo $cart_total ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>


    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script>
        function toggleDivision(divisionNumber) {
            var division = document.getElementById("division" + divisionNumber);
            var toggle = document.getElementById("toggle" + divisionNumber);
            var isOpen = !division.classList.contains("hidden");

            // Close all divisions
            var divisions = document.querySelectorAll(".left-container > div");
            for (var i = 0; i < divisions.length; i++) {
                divisions[i].classList.add("hidden");
            }

            // Remove "open" class from all toggle buttons
            var toggleButtons = document.getElementsByClassName("toggle-button");
            for (var i = 0; i < toggleButtons.length; i++) {
                toggleButtons[i].classList.remove("open");
            }

            // Open the clicked division if it was previously closed
            if (!isOpen) {
                division.classList.remove("hidden");
                toggle.classList.add("open");
            }
        }


        // FORM INVALID WORD JS

        function validateForm() {
            // var restrictedWords = ["Madhesh Pradesh", "restricted", "forbidden"]; // Restricted words

            var acceptedCityWords = ["BRT", "BIRATNAGAR", "biratnagar", "Biratnagar"]; // Accepted words for city
            var acceptedStateWords = ["Pradesh 1", "1", "Koshi Pradesh", "Koshi"]; // Accepted words for state

            var streetInput = document.getElementById("street").value;
            var cityInput = document.getElementById("city").value;
            var stateInput = document.getElementById("state").value;

            // if (containsRestrictedWord(streetInput, restrictedWords)) {
            //     alert("Invalid street input. Please avoid using restricted words.");
            //     return false;
            // }



            if (!containsAcceptedWord(cityInput, acceptedCityWords)) {
                alert("Currently we are operating in Biratnagar Only");
                return false;
            }

            if (!containsAcceptedWord(stateInput, acceptedStateWords)) {
                alert("Sorry we only operate in Koshi Pradesh");
                return false;
            }

            return true;
        }

        function containsRestrictedWord(input, restrictedWords) {
            for (var i = 0; i < restrictedWords.length; i++) {
                if (input.toLowerCase().includes(restrictedWords[i].toLowerCase())) {
                    return true;
                }
            }
            return false;
        }

        function containsAcceptedWord(input, acceptedWords) {
            for (var i = 0; i < acceptedWords.length; i++) {
                if (input.toLowerCase().includes(acceptedWords[i].toLowerCase())) {
                    return true;
                }
            }
            return false;
        }










        function manage_cart(pid, type) {
            if (type == 'update') {
                var qty = jQuery("#" + pid + "qty").val();
            } else {
                var qty = jQuery("#qty").val();
            }
            jQuery.ajax({
                url: 'manage_cart.php',
                type: 'post',
                data: 'pid=' + pid + '&qty=' + qty + '&type=' + type,
                success: function (result) {
                    if (type == 'update' || type == 'remove') {
                        window.location.href = 'checkout.php';
                    }
                    jQuery('.htc__qua').html(result);
                }
            });
        }


        // FOR RESGISTER


        function user_register() {
            jQuery('.field_error').html('');
            var name = jQuery("#name").val();
            var email = jQuery("#email").val();
            var mobile = jQuery("#mobile").val();
            var password = jQuery("#password").val();
            var is_error = '';

            if (name == "") {
                jQuery('#name_error').html('Please enter name');
                is_error = 'yes';
            }
            if (email == "") {
                jQuery('#email_error').html('Please enter email');
                is_error = 'yes';
            }
            if (mobile == "") {
                jQuery('#mobile_error').html('Please enter mobile');
                is_error = 'yes';
            } else {
                // Phone number pattern validation
                var phonePattern = /^\d{10}$/; // Assuming a 10-digit phone number is required
                if (!phonePattern.test(mobile)) {
                    jQuery('#mobile_error').html('Please enter a valid 10-digit phone number');
                    is_error = 'yes';
                }
            }
            if (password == "") {
                jQuery('#password_error').html('Please enter password');
                is_error = 'yes';
            }
            if (is_error == '') {
                jQuery.ajax({
                    url: 'register_submit.php',
                    type: 'post',
                    data: 'name=' + name + '&email=' + email + '&mobile=' + mobile + '&password=' + password,
                    success: function (result) {
                        if (result == 'email_present') {
                            jQuery('#email_error').html('Email id already present');
                        }
                        if (result == 'insert') {
                            jQuery('#register1 p').html('Thanks for registering');
                            window.location.href = window.location.href;

                        }
                    }
                });
            }
        }



        // FOR LOGIN


        function user_login() {
            jQuery('.field_error').html('');
            var email = jQuery("#login_email").val();
            var password = jQuery("#login_password").val();
            var is_error = '';
            if (email == "") {
                jQuery('#login_email_error').html('Please enter email');
                is_error = 'yes';
            }
            if (password == "") {
                jQuery('#login_password_error').html('Please enter password');
                is_error = 'yes';
            }
            if (is_error == '') {
                jQuery.ajax({
                    url: 'login_submit.php',
                    type: 'post',
                    data: 'email=' + email + '&password=' + password,
                    success: function (result) {
                        if (result == 'wrong') {
                            jQuery('#login1 p').html('Please enter valid login details');
                        }
                        if (result == 'valid') {
                            window.location.href = window.location.href;
                        }
                    }
                });
            }
        }




    </script>
</body>
<?php
require('footer.php'); ?>

</html>