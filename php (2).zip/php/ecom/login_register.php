<?php 

require('top.php'); ?> 
<!DOCTYPE html>
<html>
<head>
  <title>Login and Register Forms</title>
  <link rel="stylesheet" href="login_register.css">
 
</head>
<body>
  <div class="container">
    <div class="hello" id="login1">
      <h2>Login</h2>
      <form method="POST" id="login">
        
        <input type="email" id="login_email" name="login_email" placeholder="Enter your email" required>
        <span class="field_error" id="login_email_error"></span><br>

       
        <input type="password" id="login_password" name="login_password" placeholder="Enter your password" required>
        <span class="field_error" id="login_password_error"></span><br>

        <button type="button" onclick="user_login()">Login</button>


        
      </form>
      <div class="output">
        <p class="messege field_error "></p>
      </div>
    </div>
    <div class="hello" id="register1">
      <h2>Register</h2>
      <form method="POST" id="register">
      <input type="text" id="name" name="name" placeholder="Enter your name" required>
      <span class="field_error" id="name_error"></span><br>

 
      <input type="email" id="email" name="email" placeholder="Enter your email" required> 
      <span class="field_error" id="email_error"></span><br>


  <input type="tel" id="mobile" name="mobile" pattern="[1-9]{1}[0-9]{9}" placeholder="Enter your mobile" required>
  <span class="field_error" id="mobile_error"></span><br>


  <input type="password" id="password" name="password" placeholder="Enter your password" required>
  <span class="field_error" id="password_error"></span><br>

  <button type="button" onclick="user_register()">Register</button>
</form>

      <div class="output">
        <p class="messege field_error "></p>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
  //   function user_register(){
  //     jQuery('.field_error').html('');
	// var name=jQuery("#name").val();
	// var email=jQuery("#email").val();
	// var mobile=jQuery("#mobile").val();
	// var password=jQuery("#password").val();
  // var is_error='';
	
	// if(name==""){
	// 	jQuery('#name_error').html('Please enter name');
  //   is_error='yes';
	// }
  // if(email==""){
	// 	jQuery('#email_error').html('Please enter email');
  //   is_error='yes';
	// }
  // if(mobile==""){
	// 	jQuery('#mobile_error').html('Please enter mobile');
  //   is_error='yes';
	// }
  // if(password==""){
	// 	jQuery('#password_error').html('Please enter password');
  //   is_error='yes';
	// }
  // if(is_error==''){
	// 	jQuery.ajax({
	// 		url:'register_submit.php',
	// 		type:'post',
	// 		data:'name='+name+'&email='+email+'&mobile='+mobile+'&password='+password,
	// 		success:function(result){
	// 			if(result=='email_present'){
  //         jQuery('#email_error').html('Email id already present');
  //       }
  //       if(result=='insert'){
  //         jQuery('#register1 p ').html('Thanks for registering');
  //       }
        
                
	// 		}	
	// 	});
  // }
	// }


  // TRAIL 

  function user_register() {
  jQuery('.field_error').html('');
  var name = jQuery("#name").val();
  var email = jQuery("#email").val();
  var mobile = jQuery("#mobile").val();
  var password = jQuery("#password").val();
  var is_error = '';

  if (name == "") {
    jQuery('#name_error').html('Please enter name');
    is_error = 'yes';
  }
  if (email == "") {
    jQuery('#email_error').html('Please enter email');
    is_error = 'yes';
  }
  if (mobile == "") {
    jQuery('#mobile_error').html('Please enter mobile');
    is_error = 'yes';
  } else {
    // Phone number pattern validation
    var phonePattern = /^\d{10}$/; // Assuming a 10-digit phone number is required
    if (!phonePattern.test(mobile)) {
      jQuery('#mobile_error').html('Please enter a valid 10-digit phone number');
      is_error = 'yes';
    }
  }
  if (password == "") {
    jQuery('#password_error').html('Please enter password');
    is_error = 'yes';
  }
  if (is_error == '') {
    jQuery.ajax({
      url: 'register_submit.php',
      type: 'post',
      data: 'name=' + name + '&email=' + email + '&mobile=' + mobile + '&password=' + password,
      success: function(result) {
        if (result == 'email_present') {
          jQuery('#email_error').html('Email id already present');
        }
        if (result == 'insert') {
          jQuery('#register1 p').html('Thanks for registering');
        }
      }
    });
  }
}



// FOR LOGIN


  function user_login(){
      jQuery('.field_error').html('');
		var email=jQuery("#login_email").val();
	var password=jQuery("#login_password").val();
  var is_error='';
  if(email==""){
		jQuery('#login_email_error').html('Please enter email');
    is_error='yes';
	}
  if(password==""){
		jQuery('#login_password_error').html('Please enter password');
    is_error='yes';
	}
  if(is_error==''){
		jQuery.ajax({
			url:'login_submit.php',
			type:'post',
			data:'email='+email+'&password='+password,
			success:function(result){
				if(result=='wrong'){
          jQuery('#login1 p ').html('Please enter valid login details');
        }
        if(result=='valid'){
          window.location.href='body.php';
        }        
			}	
		});
  }
	}
  </script>
</body>
 <?php require('footer.php'); ?>
</html>