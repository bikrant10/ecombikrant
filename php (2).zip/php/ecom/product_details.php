<?php
require('top.php');
$product_id=mysqli_real_escape_string($con,$_GET['id']);
$get_product = get_product($con,'','',$product_id);

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="productdetails.css">
  <title>Document</title>
</head>
<body>
<?php if(count($get_product)>0) { ?>
<div class="main_part">
  <div class="image_container">
    <img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$get_product['0']['image'] ?>" class="img11">
  </div>
  <div class="product_details">
    <h3 class="namep"><?php echo $get_product['0']['name'] ?></h3>
    <div class="pricep">
      <span class="mrpp"><?php echo $get_product['0']['mrp'] ?></span>
      <span class="price1"><?php echo $get_product['0']['price'] ?></span>
    </div>
    <p class="pro_details_ho"><?php echo $get_product['0']['short_desc'] ?></p>
    <p>Availability: In stock</p>
    <div class="qty">
      <p>
      <span>Quantity</span>
      <select id="qty">
       <script>
         for (var i = 1; i <= 100; i++) {
         document.write('<option>' + i + '</option>');
         }
        </script>
      </select>

      </p>
    </div>
   
    <span class="label">Categories:</span>
    <p class="category"><a href="#"><?php echo $get_product['0']['categories'] ?></a></p><br>
  <button type="button"><a href="javascript:void(0)" onclick="manage_cart('<?php echo $get_product['0']['id'] ?> ','add')">ADD TO CART</a> </button>
  </div>
</div>
<div class="d-container">
  <p class="d">More Details</p>
  <div class="more-details">
    <p ><?php echo $get_product['0']['description'] ?></p>
  </div>
</div>
</div>
<?php } else{
    echo "data not found";
  } ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
 const detailsBox = document.querySelector('.d');
const moreDetails = document.querySelector('.more-details');

detailsBox.addEventListener('click', () => {
  moreDetails.classList.toggle('show');
  detailsBox.textContent = detailsBox.textContent === 'CLOSE' ? 'More Details' : 'CLOSE';
});





function manage_cart(pid,type){
		var qty=jQuery("#qty").val();
		jQuery.ajax({
			url:'manage_cart.php',
			type:'post',
			data:'pid='+pid+'&qty='+qty+'&type='+type,
			success:function(result){   
        jQuery('.badge ').html(result);
			}	
		});
  }
	

  </script>
</body>
<?php
require('footer.php');?>
</html>
