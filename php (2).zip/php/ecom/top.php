<?php

require('connection1.inc.php');
require('function1.inc.php');
require('add_to_cart.inc.php');

$cat_res=mysqli_query($con,"select * from categories where status=1 order by categories asc");
$cat_arr=array();
while($row=mysqli_fetch_assoc($cat_res)){
  $cat_arr[]=$row;
}
$obj=new add_to_cart();
$totalProduct=$obj->totalProduct();
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

  <style>
   * {
  box-sizing: border-box;
}

body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background-color: #f7d2d2;
}

header {
  background-color: #f2f2f2;
  margin-bottom: 20px;
  height: 45px;
  margin-left: 5px;
  margin-right: 5px;
}

.navbar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: transparent;
  padding: 10px;
  transition: background-color 0.3s ease-in-out, top 0.3s ease-in-out;
  z-index: 1000;
}

.navbar.scrolled {
  background-color: #f2f2f2;
}

.navbar-logo {
  font-weight: bold;
  font-size: 20px;
}

.navbar-menu {
  list-style: none;
  display: flex;
  align-items: center;
  margin: 0;
}

.navbar-menu li {
  margin-right: 15px;
  cursor: pointer;
}

.navbar-icons {
  display: flex;
  align-items: center;
}

.navbar-icons i {
  margin: 0 5px;
  cursor: pointer;
}

.content {
  padding: 20px;
  padding-top: 0px;
}

.cart-menu {
  opacity: 1;
  padding-bottom: 50px;
  right: calc(0px - 16px);
  background: #eeeeee none repeat scroll 0 0;
  box-shadow: 0 0 85px rgba(0, 0, 0, 0.2);
  display: block;
  height: 100vh;
  overflow-y: scroll;
  position: fixed;
  top: 0;
  transition: all 0.25s ease 0s;
  z-index: 99999;
  width: 475px;
}

.cart-menu.hidden {
  display: none;
}

.cart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0px;
}

.cart-items {
  max-height: 300px;
  overflow-y: auto;
  height: 130px;
  width: 370px;
  padding-left: 100px;
}

.close-icon {
  margin-left: auto;
  cursor: pointer;
  padding-top: 25px;
  padding-bottom: 25px;
}

.cart-item {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.cart-item img {
  width: 50px;
  height: 50px;
  margin-right: 10px;
}

.item-details h4,
.item-details p {
  margin: 0;
}

.remove-icon {
  margin-left: auto;
  cursor: pointer;
}

.subtotal {
  font-weight: bold;
}

.view-cart-btn,
.checkout-btn {
  margin-top: 5px;
}

table {
  border-collapse: collapse;
  width: 100%;
}

td,
th {
  border: 1px solid #ddd;
  padding: 8px;
}

img {
  width: 50px;
  height: 50px;
}

   







/* Style for the dropdown container */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Style for the dropdown button/link */
.dropbtn {
  display: inline-block;
  text-decoration: none;
  color: black;
  position: relative;
  z-index: 1;
}

/* Style for the dropdown content */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 2;
  opacity: 0;
  transform: translateY(-10px);
  transition: opacity 0.3s ease, transform 0.3s ease;
  pointer-events: none;
}

/* Style for the dropdown links */
.dropdown-content a {
  display: block;
  padding: 12px 16px;
  text-decoration: none;
  color: black;
  text-align: center;
  transition: background-color 0.3s ease;
}

/* Style for the dropdown links on hover */
.dropdown-content a:hover {
  background-color: #f1f1f1;
}

 
.dropdown:hover .dropdown-content {
  display: block;
  opacity: 1;
  transform: translateY(0);
  pointer-events: auto;
}


@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dropdown-content {
  animation: slideIn 0.3s ease forwards;
}







  </style>
</head>
<body>
  <header>
    <nav class="navbar">
      <div class="navbar-logo">
        Logo
      </div>
      
      <ul class="navbar-menu">
        <a href="body.php"><li class="drop">Home</li></a>
        <?php
        foreach($cat_arr as $list){
          ?>
          <li class="dropdown">
  <a href="frontcategories.php?id=<?php echo $list['id']?>" class="dropbtn"><?php echo $list['categories']?></a>
   
<?php
$cat_id=$list['id'];

$sub_cat_res=mysqli_query($con,"select * from sub_categories where status='1' and categories_id='$cat_id'");
if(mysqli_num_rows($sub_cat_res)>0){
?>

  <div class="dropdown-content">
    <!-- Dropdown items go here -->
 
    <?php
while($sub_cat_rows=mysqli_fetch_assoc($sub_cat_res)){
echo '<a href="frontcategories.php?id='.$list['id'].'&sub_categories='.$sub_cat_rows['id'].'">'.$sub_cat_rows['sub_categories'].'</a>';}?>
  </div>
  <?php }?>
</li>


          <?php
        }


        ?>
        
        <a href="contactfrontend.php"><li>CONTACT</li></a>
      </ul>
      <div class="navbar-icons">
        <a href="cart.php" class="cart-icon">
        <i class="fa" style="font-size:24px">&#xf07a;</i>
<span class='badge badge-warning' id='lblCartCount'><?php echo $totalProduct?></span>
        </a>&nbsp;|&nbsp;
        <?php if(isset(	$_SESSION['USER_LOGIN'])){
        echo '<a href="myorder.php">My Order</a> &nbsp;|&nbsp; <a href="logoutu.php">Logout</a>';
      }else{
        echo '<a href="login_register.php">LOGIN/REGISTER</a>';
      }
      ?>
      

      </div>
    </nav>
  </header>

  <div class="content">
  </div>

  <div class="cart-menu hidden">
    <div class="cart-header">
      
      <span class="close-icon"><i class="fas fa-times"></i></span>
    </div>
    <div class="cart-items">
      <!-- Cart items will be dynamically added here -->
      <table>
        <tr>
          <td><img src="tv.jpg" alt="Product Image" class="pcimage"></td>
          <td>
            <div class="tproduct-info">
              <div>Product Name</div>
              <div>Quantity</div>
              <div>Price</div>
            </div>
          </td>
          <td class="remove-icon"><i class="fas fa-times-circle"></i></td>
        </tr>
      </table>
    </div>
    <div class="cart-footer">
      <p class="subtotal">Subtotal: $0</p>
     
      <button class="view-cart-btn"><a href="cart.php">View Cart</a></button>
      <button class="checkout-btn">Checkout</button>
    </div>
  </div>
    <!-- Repeat the above row for each item in your table -->
 

  <script>
    // JavaScript code
// document.addEventListener('DOMContentLoaded', () => {
//   const cartIcon = document.querySelector('.cart-icon');
//   const cartMenu = document.querySelector('.cart-menu');
//   const closeIcon = document.querySelector('.close-icon');
//   const removeIcons = document.querySelectorAll('.remove-icon');

//   cartIcon.addEventListener('click', (event) => {
//     event.preventDefault();
//     cartMenu.classList.toggle('hidden');
//   });

//   closeIcon.addEventListener('click', (event) => {
//     event.preventDefault();
//     cartMenu.classList.add('hidden');
//   });

//   removeIcons.forEach((removeIcon) => {
//     removeIcon.addEventListener('click', (event) => {
//       event.preventDefault();
//       const cartItem = event.target.closest('tr');
//       cartItem.remove();
//     });
//   });
// });

  </script>
</body>
</html> 


