<?php
require('top.inc.php');

if (isset($_GET['type']) && $_GET['type'] != '') {
    $type = get_safe_value($con, $_GET['type']);

    if ($type == 'delete') {
        $id = isset($_GET['id']) ? get_safe_value($con, $_GET['id']) : '';
        if (!empty($id)) {
            $delete_sql = "DELETE FROM contact_us WHERE id='$id'";
            mysqli_query($con, $delete_sql);
        }
    }
}

$sql = "SELECT * FROM contact_us ORDER BY id DESC";
$res = mysqli_query($con, $sql);

if (isset($_POST['submit'])) {
    $id = isset($_POST['id']) ? get_safe_value($con, $_POST['id']) : '';
    $to = isset($_POST['to']) ? get_safe_value($con, $_POST['to']) : '';
    $message = isset($_POST['message']) ? $_POST['message'] : '';
    $subject = "Reply to your query";
    $headers = "From: bikrant.git@gmail.com\r\n";
    $headers .= "Cc: afgh@somedomain.com\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html\r\n";

    $retval = mail($to, $subject, $message, $headers);

    if ($retval == true) {
        echo "Message sent successfully...";
        
        $sql_status = "UPDATE contact_us SET status='1' WHERE id='$id'";
        if (mysqli_query($con, $sql_status)) {
            echo "Status updated successfully...";
        } else {
            echo "Error updating status: " . mysqli_error($con);
        }
    } else {
        echo "Message could not be sent...";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Design || Future Web</title>
    <link rel="stylesheet" href="contact_us.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        * {
            padding: 5px;
        }

        .field_error {
            color: red;
        }

        body {
            background-color: rgb(225, 236, 172);
        }

        h1 {
            padding-bottom: 0px;
            margin-top: -20px;
            margin-bottom: 0px;
            text-align: center;
        }

        /* TABLE STYLES */
        .header_fixed {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            /* overflow-x: auto; */
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ccc;
        }

        .table thead th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        .table tbody td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            border-right: 1px solid #ccc;
            word-wrap: break-word;
        }

        .table tbody td:last-child {
            border-right: none;
        }

        .table tbody td:first-child {
            font-weight: bold;
        }

        /* RESPONSIVE STYLES */
        @media only screen and (max-width: 768px) {
            .header_fixed {
                padding: 10px 0px 10px 0px;
            }

            .table {
                width: max-content;
                font-size: 7px;
            }
            .button {
                padding: 5px 0px 5px 0px;
            }
            .table thead th,
            .table tbody td {
                padding: 5px;
            }
            
        }
        @media only screen and (max-width: 386px) {
            .header_fixed {
                padding: 10px 0px 10px 0px;
                
    width: 326px;

            }

            .table {
                width: max-content;
                font-size: 5px;
            }
            .button {
                padding: 5px 0px 5px 0px;
            }
            .table thead th,
            .table tbody td {
                padding: 5px;
            }
            
        }

        /* BUTTON STYLES */
        .button {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            color: #ffffff;
            transition: background-color 0.3s ease;
        }

        .button3 {
            background-color: #1abc9c;
        }

        .button:hover {
            background-color: #f10707;
        }





        .message-box {
  display: none;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  border: 1px solid #ccc;
  padding: 10px;
  overflow: auto; 
  max-height: 70vh; 
}

.close-icon {
  float: right;
  cursor: pointer;
}





























.reply-box {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 10px;
            overflow: auto;
            max-height: 70vh;
        }

        .reply-box .reply-content {
            margin-bottom: 10px;
        }

        .reply-box .close-icon {
            float: right;
            cursor: pointer;
        }

        .reply-form input,
        .reply-form textarea {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
        }

        .reply-form button {
            padding: 5px 10px;
            background-color: #1abc9c;
            color: #fff;
            border: none;
            cursor: pointer;
        }

    </style>
</head>

<body>
    
    <br>
    <h1>Message Received From Users</h1>

    <div class="header_fixed">
        <table class="table">
            <thead>
                <tr>
                    <th>Serial</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>Query</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                while ($row = mysqli_fetch_assoc($res)) {
                    $id = $row['id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $mobile = $row['mobile'];
                    $comment = $row['comment'];
                    $added_on = $row['added_on'];
                    $status = $row['status'];
                ?>
                    <tr>
                        <td data-label="Serial"><?php echo $i ?></td>
                        <td data-label="ID"><?php echo $row['id'] ?></td>
                        <td data-label="Name"><?php echo $row['name'] ?></td>
                        <td data-label="Email"><?php echo $row['email'] ?></td>
                        <td data-label="Mobile"><?php echo $row['mobile'] ?></td>
                        <td>
                            <button class="see-message-btn" data-id="<?php echo $row['id']; ?>">See Message</button>
                            <div class="message-box" id="message-box-<?php echo $row['id']; ?>">
                                <div class="message-content">
                                    <span class="close-icon">&times;</span>
                                    <?php echo $row['comment']; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php
                            if ($row['status'] == 0) {
                                echo "Not Replied";
                            } else {
                                echo "Replied";
                            }
                            ?>
                        </td>
                        <td data-label="Date"><?php echo $row['added_on'] ?></td>
                        <td>
                            <?php
                            echo "<span class='button button3'><a href='?type=delete&id=" . $row['id'] . "'>Delete</a></span>&nbsp;";
                            ?>
                            <button class="reply-btn" data-email="<?php echo $row['email']; ?>">Reply</button>
                        </td>
                    </tr>
                <?php
                    $i++;
                }
                ?>
            </tbody>
        </table>
    </div>

    <div class="reply-box" id="reply-box">
        <div class="reply-content">
            <span class="close-icon">&times;</span>
            <form class="reply-form" method="post" action="">
                <input type="hidden" name="id" id="recipient-id">
                <input type="email" name="to" id="recipient-email" placeholder="Recipient Email" required>
                <textarea name="message" placeholder="Your Message" required></textarea>
                <button type="submit" name="submit">Send</button>
            </form>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.see-message-btn').click(function() {
                var messageBox = $(this).next('.message-box');
                messageBox.show();
                $(this).hide();
            });

            $('.close-icon').click(function() {
                var messageBox = $(this).closest('.message-box');
                var seeMessageBtn = messageBox.prev('.see-message-btn');
                seeMessageBtn.show();
                messageBox.hide();
            });

            $('.reply-btn').click(function() {
                var replyBox = $('#reply-box');
                var recipientEmail = $(this).data('email');
                var recipientId = $(this).closest('tr').find('[data-label="ID"]').text();
                $('#recipient-email').val(recipientEmail);
                $('#recipient-id').val(recipientId);
                replyBox.show();
            });

            $('.close-icon').click(function() {
                var replyBox = $('#reply-box');
                replyBox.hide();
            });
        });
    </script>

</body>

<?php
require('footer.inc.php');
?>

</html>
